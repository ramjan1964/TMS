

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Entry Form</title>
    <!-- Add your CSS styles or include Bootstrap CSS if needed -->
    <!--load progress bar-->
    <script src="vendor/pace/pace.min.js"></script>
    <link href="vendor/pace/pace-theme-minimal.css" rel="stylesheet" />
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="vendor/animate.css/animate.css">
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--Notification msj-->
    <link rel="stylesheet" href="vendor/toastr/toastr.min.css">
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="stylesheets/css/style.css">
</head>

<body>

    <div class="col-md-8 col-md-offset-2 col-lg-6 col-lg-offset-0">
        <h4 class="section-subtitle"><b>Arrows Block</b> wizard <small>(Validation disabled)</small></h4>
        <div class="panel">
            <div class="panel-content">
                <div class="form-wizard wizard-block wizard-arrows">

                <form id="wizard-4" action="process.php" method="POST" novalidate="novalidate">
    <!-- ... (rest of your HTML) ... -->
</form>
                <div class="tab-steps">
                            <ul class="steps">
                                <li class="active"><a href="#w4-tab1" data-toggle="tab"><span class="tab-number">1</span>First</a></li>
                                <li><a href="#w4-tab2" data-toggle="tab"><span class="tab-number">2</span>Second</a></li>
                                <li><a href="#w4-tab3" data-toggle="tab"><span class="tab-number">3</span>Third</a></li>
                            </ul>
                        </div>
                        <div class="tab-content">
                            <div class="tab-pane active" id="w4-tab1">

                                <div class="form-group">
                                    <label for="w4-username" class="control-label">Username<span class="required"
                                            aria-required="true">*</span></label>
                                    <input type="text" class="form-control" id="w4-username" name="username" required=""
                                        aria-required="true">
                                </div>
                                <div class="form-group">
                                    <label for="w4-password" class="control-label">Password<span class="required"
                                            aria-required="true">*</span></label>
                                    <input type="password" class="form-control" id="w4-password" name="password"
                                        required="" aria-required="true">
                                </div>
                            </div>
                            <div class="tab-pane" id="w4-tab2">
                                <div class="form-group">
                                    <label for="w4-name" class="control-label">Name<span class="required"
                                            aria-required="true">*</span></label>
                                    <input type="text" class="form-control" id="w4-name" name="name" required=""
                                        aria-required="true">
                                </div>
                                <div class="form-group">
                                    <label for="w4-email" class="control-label">Email<span class="required"
                                            aria-required="true">*</span></label>
                                    <input type="email" class="form-control" id="w4-email" name="email" required=""
                                        aria-required="true">
                                </div>
                            </div>
                            <div class="tab-pane" id="w4-tab3">

                                <div class="form-group">
                                    <label for="w4-age" class="control-label">Age<span class="required"
                                            aria-required="true">*</span></label>
                                    <input type="text" class="form-control" id="w4-age" name="age" required=""
                                        aria-required="true">
                                </div>
                                <div class="form-group">
                                    <div class="checkbox-custom checkbox-primary">
                                        <input type="checkbox" id="w4-terms" name="terms" value="option1">
                                        <label class="check" for="w4-terms">I agree </label> to the <a
                                            href="#">Terms and Conditions</a>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="tab-buttons">
                            <a class="btn btn-primary previous disabled">Previous</a>
                            <button type="submit" class="btn btn-primary finish hidden">Submit</button>
                            <a class="btn btn-primary next">Next</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- Add your JavaScript scripts or include Bootstrap/other JS libraries if needed -->
<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="javascripts/template-script.min.js"></script>
<script src="javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!-- ========================================================= -->
<!--Notification msj-->
<script src="vendor/toastr/toastr.min.js"></script>
<!--Form wizard-->
<script src="vendor/twitter-bootstrap-wizard/jquery.bootstrap.wizard.js"></script>
<!--jquery Validate-->
<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
<!--example-->
<script src="javascripts/examples/forms/wizard.js"></script>
</body>

</html>
