<?php
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (
        isset($_POST['ProductName']) && !empty($_POST['ProductName']) &&
        isset($_POST['CategoryID']) && !empty($_POST['CategoryID']) &&
        isset($_POST['GroupID']) && !empty($_POST['GroupID']) &&
        isset($_POST['SubGroupID']) && !empty($_POST['SubGroupID'])
    ) {
        // Get data from the form
        $ProductName = $_POST['ProductName'];
        $CategoryID = $_POST['CategoryID'];
        $GroupID = $_POST['GroupID'];
        $SubGroupID = $_POST['SubGroupID'];

        // Insert data into the database
        $sql = "INSERT INTO ProductManagement (CategoryID, GroupID, SubGroupID, ProductName) VALUES ($CategoryID, $GroupID, $SubGroupID, '$ProductName')";

        if ($conn->query($sql) === TRUE) {
            $success = "Product added successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Product Name, Category, Group, and Subgroup are required";
    }
}
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Product</a></li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Rest of your HTML code goes here -->
            <h4 class="section-subtitle"><b>Product</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Product</h4>

                                <div class="form-group">
                                    <label for="CategoryID" class="col-sm-4 control-label">Category:</label>
                                    <div class="col-sm-8">
                                        <!-- Dropdown for selecting Category -->
                                        <select class="form-control" id="CategoryID" name="CategoryID">
                                            <!-- Fetch and display categories from the database -->
                                            <?php
                                            $categoryQuery = "SELECT * FROM CategoryManagement";
                                            $categoryResult = $conn->query($categoryQuery);

                                            while ($row = $categoryResult->fetch_assoc()) {
                                                echo "<option value='{$row['CategoryID']}'>{$row['CategoryName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="GroupID" class="col-sm-4 control-label">Group:</label>
                                    <div class="col-sm-8">
                                        <!-- Dropdown for selecting Group -->
                                        <select class="form-control" id="GroupID" name="GroupID">
                                            <!-- Fetch and display groups from the database -->
                                            <?php
                                            $groupQuery = "SELECT * FROM GroupManagement";
                                            $groupResult = $conn->query($groupQuery);

                                            while ($row = $groupResult->fetch_assoc()) {
                                                echo "<option value='{$row['GroupID']}'>{$row['GroupName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="SubGroupID" class="col-sm-4 control-label">Subgroup:</label>
                                    <div class="col-sm-8">
                                        <!-- Dropdown for selecting Subgroup -->
                                        <select class="form-control" id="SubGroupID" name="SubGroupID">
                                            <!-- Fetch and display subgroups from the database -->
                                            <?php
                                            $subgroupQuery = "SELECT * FROM SubGroupManagement";
                                            $subgroupResult = $conn->query($subgroupQuery);

                                            while ($row = $subgroupResult->fetch_assoc()) {
                                                echo "<option value='{$row['SubGroupID']}'>{$row['SubGroupName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="ProductName" class="col-sm-4 control-label">Product Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ProductName" name='ProductName'
                                            placeholder="Type the Product Name"
                                            value="<?= isset($ProductName) ? $ProductName : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_product"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                            <!-- ... -->

                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

                        <!--scroll to top-->
                        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
                    </div>
                </div>

                <?php
                require_once 'footer.php';
                ?>
