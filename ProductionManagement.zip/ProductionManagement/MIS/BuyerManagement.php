<?php
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (isset($_POST['BusinessUnitID'], $_POST['BuyerName']) && !empty($_POST['BuyerName'])) {
        // Get data from the form
        $BusinessUnitID = $_POST['BusinessUnitID'];
        $BuyerName = $_POST['BuyerName'];
        $ContactPerson = isset($_POST['ContactPerson']) ? $_POST['ContactPerson'] : '';
        $ContactNumber = isset($_POST['ContactNumber']) ? $_POST['ContactNumber'] : '';
        $BondAddress = isset($_POST['BondAddress']) ? $_POST['BondAddress'] : '';
        $MailAddress = isset($_POST['MailAddress']) ? $_POST['MailAddress'] : '';

        // If "All Over BUnit" is selected, fetch all Business Units
        $businessUnits = [];
        if ($BusinessUnitID == 'all_over_bunit') {
            $result = $conn->query("SELECT BusinessUnitID FROM BusinessUnitManagement");
            while ($row = $result->fetch_assoc()) {
                $businessUnits[] = $row['BusinessUnitID'];
            }
        } else {
            // If a specific Business Unit is selected, add only that one
            $businessUnits[] = $BusinessUnitID;
        }

        // Insert data into the database for each Business Unit
        foreach ($businessUnits as $bUnit) {
            $sql = "INSERT INTO Buyers (BusinessUnitID, BuyerName, ContactPerson, ContactNumber, BondAddress, MailAddress) 
                    VALUES ('$bUnit', '$BuyerName', '$ContactPerson', '$ContactNumber', '$BondAddress', '$MailAddress')";

            if ($conn->query($sql) !== TRUE) {
                $error = "Error: " . $sql . "<br>" . $conn->error;
                break; // Exit the loop if an error occurs
            }
        }

        if (empty($error)) {
            $success = "Buyer(s) added successfully!";
        }
    } else {
        $error = "Buyer Name is required";
    }
}
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Buyer</a></li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Rest of your HTML code goes here -->
            <h4 class="section-subtitle"><b>Buyer</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Buyer</h4>

                                <div class="form-group">
                                    <label for="BusinessUnitID" class="col-sm-4 control-label">Business Unit:</label>
                                    <div class="col-sm-8">
                                        <!-- Assuming you have a BusinessUnitManagement table -->
                                        <select class="form-control" id="BusinessUnitID" name='BusinessUnitID'>
                                            <option value="">Select Business Unit</option>
                                            <option value="all_over_bunit">All Over BUnit</option>
                                            <?php
                                            // Fetch Business Units from the database
                                            $result = $conn->query("SELECT BusinessUnitID, BusinessUnitName FROM BusinessUnitManagement");
                                            while ($row = $result->fetch_assoc()) {
                                                echo "<option value='{$row['BusinessUnitID']}'>{$row['BusinessUnitName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="BuyerName" class="col-sm-4 control-label">Buyer Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="BuyerName" name='BuyerName'
                                            placeholder="Type the Buyer Name"
                                            value="<?= isset($BuyerName) ? $BuyerName : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="ContactPerson" class="col-sm-4 control-label">Contact Person:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ContactPerson" name='ContactPerson'
                                            placeholder="Type the Contact Person"
                                            value="<?= isset($ContactPerson) ? $ContactPerson : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="ContactNumber" class="col-sm-4 control-label">Contact Number:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ContactNumber" name='ContactNumber'
                                            placeholder="Type the Contact Number"
                                            value="<?= isset($ContactNumber) ? $ContactNumber : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="BondAddress" class="col-sm-4 control-label">Bond Address:</label>
                                    <div class="col-sm-8">
                                        <textarea class="form-control" id="BondAddress" name='BondAddress'
                                            placeholder="Type the Bond Address"><?= isset($BondAddress) ? $BondAddress : '' ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="MailAddress" class="col-sm-4 control-label">Mail Address:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="MailAddress" name='MailAddress'
                                            placeholder="Type the Mail Address"
                                            value="<?= isset($MailAddress) ? $MailAddress : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_order"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                            <!-- ... -->

                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

                        <!--scroll to top-->
                        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
                    </div>
                </div>

                <?php
                require_once 'footer.php';
                ?>
