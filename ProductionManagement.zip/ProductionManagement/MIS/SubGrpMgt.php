<?php
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (
        isset($_POST['SubGroupName']) && !empty($_POST['SubGroupName']) &&
        isset($_POST['CategoryID']) && !empty($_POST['CategoryID']) &&
        isset($_POST['GroupID']) && !empty($_POST['GroupID'])
    ) {
        // Get data from the form
        $SubGroupName = $_POST['SubGroupName'];
        $CategoryID = $_POST['CategoryID'];
        $GroupID = $_POST['GroupID'];

        // Insert data into the database
        $sql = "INSERT INTO SubGroupManagement (CategoryID, GroupID, SubGroupName) VALUES ($CategoryID, $GroupID, '$SubGroupName')";

        if ($conn->query($sql) === TRUE) {
            $success = "Subgroup added successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Subgroup Name, Category, and Group are required";
    }
}
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Subgroup</a></li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Rest of your HTML code goes here -->
            <h4 class="section-subtitle"><b>Subgroup</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Subgroup</h4>

                                <div class="form-group">
                                    <label for="CategoryID" class="col-sm-4 control-label">Category:</label>
                                    <div class="col-sm-8">
                                        <!-- Dropdown for selecting Category -->
                                        <select class="form-control" id="CategoryID" name="CategoryID">
                                            <!-- Fetch and display categories from the database -->
                                            <?php
                                            $categoryQuery = "SELECT * FROM CategoryManagement";
                                            $categoryResult = $conn->query($categoryQuery);

                                            while ($row = $categoryResult->fetch_assoc()) {
                                                echo "<option value='{$row['CategoryID']}'>{$row['CategoryName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="GroupID" class="col-sm-4 control-label">Group:</label>
                                    <div class="col-sm-8">
                                        <!-- Dropdown for selecting Group -->
                                        <select class="form-control" id="GroupID" name="GroupID">
                                            <!-- Fetch and display groups from the database -->
                                            <?php
                                            $groupQuery = "SELECT * FROM GroupManagement";
                                            $groupResult = $conn->query($groupQuery);

                                            while ($row = $groupResult->fetch_assoc()) {
                                                echo "<option value='{$row['GroupID']}'>{$row['GroupName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="SubGroupName" class="col-sm-4 control-label">Subgroup Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="SubGroupName" name='SubGroupName'
                                            placeholder="Type the Subgroup Name"
                                            value="<?= isset($SubGroupName) ? $SubGroupName : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_subgroup"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                            <!-- ... -->

                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

                        <!--scroll to top-->
                        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
                    </div>
                </div>

                <?php
                require_once 'footer.php';
                ?>
