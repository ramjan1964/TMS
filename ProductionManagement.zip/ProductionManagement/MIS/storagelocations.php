<?php
// Include necessary files
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    $requiredFields = ['LocationName'];

    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field])) {
            $error = "Error: The field '$field' is not set.";
            break;  // Stop the loop if any required field is not set
        }
    }

    if (empty($error)) {
        // Get data from the form
        $LocationName = $_POST['LocationName'];

        // Insert data into the database
        $sql = "INSERT INTO storagelocations (LocationName) VALUES ('$LocationName')";

        if ($conn->query($sql) === TRUE) {
            $success = "Storage location added successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Please fill in all the required fields";
    }
}
?>

<!-- Content for storagelocations.php -->
<div class="content">
    <!-- content HEADER -->
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Storage Locations</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <h4 class="section-subtitle"><b>Storage Location</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

                                <!-- LocationName Input -->
                                <div class="form-group">
                                    <label for="LocationName" class="col-sm-4 control-label">Location Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="LocationName" name="LocationName" placeholder="Enter location name">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_location"><i class="fa fa-save"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'footer.php';
?>
