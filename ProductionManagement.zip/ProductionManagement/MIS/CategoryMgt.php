<?php
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    if (isset($_POST['CategoryName']) && !empty($_POST['CategoryName'])) {
        // Get data from the form
        $CategoryName = $_POST['CategoryName'];

        // Insert data into the database
        $sql = "INSERT INTO CategoryManagement (CategoryName) VALUES ('$CategoryName')";

        if ($conn->query($sql) === TRUE) {
            $success = "Category added successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Category Name is required";
    }
}
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Category</a></li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Rest of your HTML code goes here -->
            <h4 class="section-subtitle"><b>Category</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Category</h4>

                                <div class="form-group">
                                    <label for="CategoryName" class="col-sm-4 control-label">Category Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="CategoryName" name='CategoryName'
                                            placeholder="Type the Category Name"
                                            value="<?= isset($CategoryName) ? $CategoryName : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_category"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                            <!-- ... -->

                        </div>
                        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

                        <!--scroll to top-->
                        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
                    </div>
                </div>

                <?php
                require_once 'footer.php';
                ?>
