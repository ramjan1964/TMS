<!--BASIC scripts-->
<!-- ========================================================= -->
<script src="../vendor/jquery/jquery-1.12.3.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="../vendor/nano-scroller/nano-scroller.js"></script>
<!--TEMPLATE scripts-->
<!-- ========================================================= -->
<script src="../javascripts/template-script.min.js"></script>
<script src="../javascripts/template-init.min.js"></script>
<!-- SECTION script and examples-->
<!--dataTable-->
<script src="../vendor/data-table/media/js/jquery.dataTables.min.js"></script>
<script src="../vendor/data-table/media/js/dataTables.bootstrap.min.js"></script>
<!--Examples-->
<script src="../javascripts/examples/tables/data-tables.js"></script>
</body>

<!-- ========================================================= -->
</body>


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/forms_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:05:56 GMT -->
</html>
