<?php
require_once '../test/db_config.php';
require_once '../header.php';
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Purchase Order Management</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">

            <!-- Purchase Order Management List -->
            <div class="panel">

                <div class="panel-content">
                    <h5>Purchase Order Management List</h5>
                    <div class="table-responsive">
                        <table id="basic-table"
                            class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered"
                            cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">Purchase Order ID</th>
                                    <th style="text-align: center;">Supplier</th>
                                    <th style="text-align: center;">Product</th>
                                    <th style="text-align: center;">Quantity</th>
                                    <th style="text-align: center;">Weight ID</th>
                                    <th style="text-align: center;">Price</th>
                                    <th style="text-align: center;">Amount</th>
                                    <th style="text-align: center;">Currency</th>
                                    <th style="text-align: center;">Order Date</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch Purchase Order Management data
                                $purchaseOrderSql = "SELECT pom.*, s.supplierName, pm.productName, w.WeightName,c.CurrencyName
                                FROM purchaseordermanagement pom
                                JOIN suppliers s ON pom.SupplierID = s.SupplierID
                                JOIN productmanagement pm ON pom.ProductID = pm.ProductID
                                JOIN weightunitmanagement w ON pom.WeightID=w.WeightID
                                JOIN currencymanagement c ON pom.CurrencyID=c.CurrencyID";
                                $purchaseOrderResult = $conn->query($purchaseOrderSql);
                                if ($purchaseOrderResult->num_rows > 0): ?>
                                    <?php while ($purchaseOrderRow = $purchaseOrderResult->fetch_assoc()): ?>
                                        <tr>
                                            <td style="text-align: center;"><?= $purchaseOrderRow['PurchaseOrderID'] ?></td>
                                            <td><?= $purchaseOrderRow['supplierName'] ?></td>
                                            <td><?= $purchaseOrderRow['productName'] ?></td>
                                            <td><?= $purchaseOrderRow['PurchaseOrderQuantity'] ?></td>
                                            <td><?= $purchaseOrderRow['WeightName'] ?></td>
                                            <td><?= $purchaseOrderRow['Price'] ?></td>
                                            <td><?= $purchaseOrderRow['Amount'] ?></td>
                                            <td><?= $purchaseOrderRow['CurrencyName'] ?></td>
                                            <td><?= $purchaseOrderRow['PurchaseOrderDate'] ?></td>

                                            <td>
                                                <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal'
                                                    data-target='#view-modal-<?= $purchaseOrderRow['PurchaseOrderID'] ?>'><i
                                                        class='fa fa-eye'></i></a>
                                                <a href='javascript:avoid(0)' class='btn btn-warning' data-toggle='modal'
                                                    data-target='#edit-modal-<?= $purchaseOrderRow['PurchaseOrderID'] ?>'><i
                                                        class='fa fa-pencil'></i></a>
                                                <!-- Add other actions as needed -->

                                            </td>

                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="10">No purchase orders found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- End Purchase Order Management List -->
            </div>
        </div>

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>

<?php
// Fetch Purchase Order Management Data for modals
$purchaseOrderResult = $conn->query($purchaseOrderSql);
if ($purchaseOrderResult->num_rows > 0): ?>
    <?php while ($purchaseOrderRow = $purchaseOrderResult->fetch_assoc()): ?>
       <!-- View Modal -->
<div class="modal fade" id="view-modal-<?= $purchaseOrderRow['PurchaseOrderID'] ?>" tabindex="-1" role="dialog"
    aria-labelledby="view-modal-label">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i>Purchase Order Information:</h4>
            </div>
            <table class="table table-bordered">
                <tr>
                    <th style="text-align: center;">Purchase Order ID</th>
                    <th>Supplier</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Weight Unit</th>
                    <th>Price</th>
                    <th>Amount</th>
                    <th>Currency</th>
                    <th>Order Date</th>
                </tr>
                <tr>
                    <td style="text-align: center;"><?= $purchaseOrderRow['PurchaseOrderID'] ?></td>
                    <td><?= $purchaseOrderRow['supplierName'] ?></td>
                    <td><?= $purchaseOrderRow['productName'] ?></td>
                    <td><?= $purchaseOrderRow['PurchaseOrderQuantity'] ?></td>
                    <td><?= $purchaseOrderRow['WeightName'] ?></td>
                    <td><?= $purchaseOrderRow['Price'] ?></td>
                    <td><?= $purchaseOrderRow['Amount'] ?></td>
                    <td><?= $purchaseOrderRow['CurrencyName'] ?></td>
                    <td><?= $purchaseOrderRow['PurchaseOrderDate'] ?></td>
                </tr>
            </table>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

      <!-- Edit Modal -->
<div class="modal fade" id="edit-modal-<?= $purchaseOrderRow['PurchaseOrderID'] ?>" tabindex="-1" role="dialog"
    aria-labelledby="edit-modal-label">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-warning">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-update-label"><i class="fa fa-pencil"></i>Edit Purchase Order:</h4>
            </div>
            <div class="modal-body">
                <!-- Form for editing purchase order data -->
                <form action="update_purchase_order.php" method="POST">
                    <!-- Include purchase order ID for identifying the record to update -->
                    <input type="hidden" name="purchase_order_id" value="<?= $purchaseOrderRow['PurchaseOrderID'] ?>">

                    <!-- Add input fields for editing data -->
                    <div class="form-group">
                        <label for="edit_supplier">Supplier:</label>
                        <input type="text" class="form-control" id="edit_supplier" name='edit_supplier'
                            value="<?= $purchaseOrderRow['supplierName'] ?>">
                    </div>

                    <?php
// Fetch weight unit names from the weightunitmanagement table
$weightUnitsSql = "SELECT WeightName FROM weightunitmanagement";
$weightUnitsResult = $conn->query($weightUnitsSql);

// Check if query was successful
if ($weightUnitsResult) {
    // Fetch weight unit names as an associative array
    $weightUnits = $weightUnitsResult->fetch_all(MYSQLI_ASSOC);
} else {
    // Handle the error, for example, log it or display a default list
    $weightUnits = array();
}

?>

<!-- Display the WeightName dropdown in the form -->
<div class="form-group">
    <label for="edit_WeightName">Weight Name:</label>
    <select class="form-control" id="edit_WeightName" name="edit_WeightName">
        <?php foreach ($weightUnits as $weightUnit): ?>
            <option value="<?= $weightUnit['WeightName'] ?>" <?= $weightUnit['WeightName'] === $purchaseOrderRow['WeightName'] ? 'selected' : '' ?>>
                <?= $weightUnit['WeightName'] ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

                    <div class="form-group">
                        <label for="edit_Price">Price:</label>
                        <input type="number" class="form-control" id="edit_PurchaseOrderQuantity" name='edit_Price'
                            value="<?= $purchaseOrderRow['Price'] ?>">
                    </div>
                    <div class="form-group">
                        <label for="edit_Price">Amount:</label>
                        <input type="number" class="form-control" id="edit_Amount" name='edit_Amount'
                            value="<?= $purchaseOrderRow['Amount'] ?>">
                    </div>
                    <?php
// Fetch currency names from the currencymanagement table
$currencySql = "SELECT CurrencyName FROM currencymanagement";
$currencyResult = $conn->query($currencySql);

// Check if query was successful
if ($currencyResult) {
    // Fetch currency names as an associative array
    $currencies = $currencyResult->fetch_all(MYSQLI_ASSOC);
} else {
    // Handle the error, for example, log it or display a default list
    $currencies = array();
}

?>

<!-- Display the CurrencyName dropdown in the form -->
<div class="form-group">
    <label for="edit_CurrencyName">Currency Name:</label>
    <select class="form-control" id="edit_CurrencyName" name="edit_CurrencyName">
        <?php foreach ($currencies as $currency): ?>
            <option value="<?= $currency['CurrencyName'] ?>" <?= $currency['CurrencyName'] === $purchaseOrderRow['CurrencyName'] ? 'selected' : '' ?>>
                <?= $currency['CurrencyName'] ?>
            </option>
        <?php endforeach; ?>
    </select>
</div>

                    <div class="form-group">
                        <label for="edit_PurchaseOrderDate">Purchase Order Date:</label>
                        <input type="date" class="form-control" id="edit_PurchaseOrderDate" name='edit_PurchaseOrderDate'
                            value="<?= $purchaseOrderRow['PurchaseOrderDate'] ?>">
                    </div>


                    <!-- Add other input fields as needed -->

            </div>
            <div class="modal-footer">
                <div class="form-group">
                    <button type="submit" class="btn btn-warning">Update</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>
    <?php endwhile; ?>
<?php else: ?>

<?php endif; ?>

<?php
require_once 'footer.php';
?>
