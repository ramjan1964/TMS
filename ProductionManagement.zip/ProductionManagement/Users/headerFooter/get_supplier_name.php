<?php
// Connect to the database (replace placeholders with actual details)
$mysqli = new mysqli('localhost', 'root', '', 'tms');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Retrieve PurchaseOrderID from the request
$purchaseOrderId = $_GET['purchaseOrderId'];

// Fetch SupplierName from the database based on the selected PurchaseOrderID
$query = "SELECT s.SupplierName 
          FROM purchaseordermanagement pom
          JOIN suppliers s ON pom.SupplierID = s.SupplierID
          WHERE pom.PurchaseOrderID = '$purchaseOrderId'";

$result = $mysqli->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $supplierName = $row['SupplierName'];

    echo $supplierName;
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
