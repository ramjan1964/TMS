<?php
// Include necessary files
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    $requiredFields = ['PurchaseOrderID', 'ProductID', 'SupplierID', 'ReceivedQuantity', 'WeightID', 'ReceiveDate'];

    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field])) {
            $error = "Error: The field '$field' is not set.";
            break;  // Stop the loop if any required field is not set
        }
    }

    if (empty($error)) {
        // Get data from the form
        $PurchaseOrderID = $_POST['PurchaseOrderID'];
        $ProductID = $_POST['ProductID'];
        $SupplierID = $_POST['SupplierID'];
        $ReceivedQuantity = $_POST['ReceivedQuantity'];
        $WeightID = $_POST['WeightID'];
        $ReceiveDate = $_POST['ReceiveDate'];

        // Insert data into the database
        $sql = "INSERT INTO yarnreceivemanagement (PurchaseOrderID, ProductID, SupplierID, ReceivedQuantity, WeightID, ReceiveDate) 
                VALUES ('$PurchaseOrderID', '$ProductID', '$SupplierID', '$ReceivedQuantity', '$WeightID', '$ReceiveDate')";

        if ($conn->query($sql) === TRUE) {
            $success = "Yarn received successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Please fill in all the required fields";
    }
}
?>

<!-- Content for yarnreceivemanagement.php -->
<div class="content">
    <!-- content HEADER -->
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Yarn Receive Management</a></li>
            </ul>
        </div>
    </div>
    <div class="row animated fadeInUp">
        <div class="col-md-12">

            <!-- Display datatable and Add button -->
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal">
                                <i class="fa fa-plus"></i> Add
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
    <div class="row animated fadeInUp">
        <div class="col-md-12">

            <!-- Display datatable and Add button -->
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                         
                            <hr>

                            <!-- Datatable for displaying inputted data -->
                            <table id="dataTable" class="table table-striped table-bordered dataTable">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <!-- Add more columns as needed -->
                                        <th>Receive No:</th>
                                        <th>Purchase Order No:</th>
                                        <th>Product Name</th>
                                        <th>Supplier Name</th>
                                        <th>Received Quantity</th>
                                        <th>Weight UNIT</th>
                                        <th>Receive Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Fetch and display data from the database with related names
                                    $sql = "SELECT y.*, p.ProductName, s.SupplierName, w.WeightName
                                            FROM yarnreceivemanagement y
                                            INNER JOIN productmanagement p ON y.ProductID = p.ProductID
                                            INNER JOIN suppliers s ON y.SupplierID = s.SupplierID
                                            INNER JOIN weightunitmanagement w ON y.WeightID = w.WeightID";
                                    $result = $conn->query($sql);

                                    if ($result && $result->num_rows > 0) {
                                        $count = 1;
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td>' . $count . '</td>';
                                            // Add more columns as needed
                                            echo '<td>' . $row['ReceiveYarnId'] . '</td>';
                                            echo '<td>' . $row['PurchaseOrderID'] . '</td>';
                                            echo '<td>' . $row['ProductName'] . '</td>';
                                            echo '<td>' . $row['SupplierName'] . '</td>';
                                            echo '<td>' . $row['ReceivedQuantity'] . '</td>';
                                            echo '<td>' . $row['WeightName'] . '</td>';
                                            echo '<td>' . $row['ReceiveDate'] . '</td>';
                                            echo '</tr>';
                                            $count++;
                                        }
                                    } else {
                                        echo '<tr><td colspan="7">No data available</td></tr>';
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal for input -->
            <div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="addModalLabel">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="addModalLabel">Add Yarn Receive</h4>
                        </div>
                        <div class="modal-body">
                            <!-- Include the form for input (use the existing form) -->
                            <!-- Include this file in the modal body -->
<form class="form-horizontal" action="test.php" method="POST" enctype="multipart/form-data">
    <!-- PurchaseOrderID Dropdown -->
    <div class="form-group">
        <label for="PurchaseOrderID" class="col-sm-4 control-label">Purchase Order:</label>
        <div class="col-sm-8">
            <select class="form-control" id="PurchaseOrderID" name="PurchaseOrderID">
                <option>Select One</option>
                <?php
                // Fetch purchase orders from the database
                $sqlPurchaseOrders = "SELECT PurchaseOrderID FROM PurchaseOrderManagement";
                $resultPurchaseOrders = $conn->query($sqlPurchaseOrders);

                if ($resultPurchaseOrders && $resultPurchaseOrders->num_rows > 0) {
                    while ($rowPurchaseOrder = $resultPurchaseOrders->fetch_assoc()) {
                        echo '<option value="' . $rowPurchaseOrder['PurchaseOrderID'] . '">' . $rowPurchaseOrder['PurchaseOrderID'] . '</option>';
                    }
                } else {
                    echo '<option value="" disabled>No purchase orders available</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <!-- Add more input fields as needed -->
    <!-- ProductID Dropdown -->
    <div class="form-group">
        <label for="ProductID" class="col-sm-4 control-label">Product:</label>
        <div class="col-sm-8">
            <select class="form-control" id="ProductID" name="ProductID">
                <option>Select One</option>
                <?php
                // Fetch products from the database
                $sqlProducts = "SELECT ProductID, ProductName FROM productmanagement";
                $resultProducts = $conn->query($sqlProducts);

                if ($resultProducts && $resultProducts->num_rows > 0) {
                    while ($rowProduct = $resultProducts->fetch_assoc()) {
                        echo '<option value="' . $rowProduct['ProductID'] . '">' . $rowProduct['ProductName'] . '</option>';
                    }
                } else {
                    echo '<option value="" disabled>No products available</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <!-- SupplierID Dropdown -->
    <div class="form-group">
        <label for="SupplierID" class="col-sm-4 control-label">Supplier:</label>
        <div class="col-sm-8">
            <select class="form-control" id="SupplierID" name="SupplierID">
                <option>Select One</option>
                <?php
                // Fetch suppliers from the database
                $sqlSuppliers = "SELECT SupplierID, SupplierName FROM suppliers";
                $resultSuppliers = $conn->query($sqlSuppliers);

                if ($resultSuppliers && $resultSuppliers->num_rows > 0) {
                    while ($rowSupplier = $resultSuppliers->fetch_assoc()) {
                        echo '<option value="' . $rowSupplier['SupplierID'] . '">' . $rowSupplier['SupplierName'] . '</option>';
                    }
                } else {
                    echo '<option value="" disabled>No suppliers available</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <!-- ReceivedQuantity Input -->
    <div class="form-group">
        <label for="ReceivedQuantity" class="col-sm-4 control-label">Received Quantity:</label>
        <div class="col-sm-8">
            <input type="text" class="form-control" id="ReceivedQuantity" name="ReceivedQuantity" placeholder="Enter received quantity">
        </div>
    </div>

    <!-- WeightID Dropdown -->
    <div class="form-group">
        <label for="WeightID" class="col-sm-4 control-label">Weight:</label>
        <div class="col-sm-8">
            <select class="form-control" id="WeightID" name="WeightID">
                <option>Select One</option>
                <?php
                // Fetch weights from the database
                $sqlWeights = "SELECT WeightID, WeightName FROM weightunitmanagement";
                $resultWeights = $conn->query($sqlWeights);

                if ($resultWeights && $resultWeights->num_rows > 0) {
                    while ($rowWeight = $resultWeights->fetch_assoc()) {
                        echo '<option value="' . $rowWeight['WeightID'] . '">' . $rowWeight['WeightName'] . '</option>';
                    }
                } else {
                    echo '<option value="" disabled>No weights available</option>';
                }
                ?>
            </select>
        </div>
    </div>

    <!-- ReceiveDate Input -->
    <div class="form-group">
        <label for="ReceiveDate" class="col-sm-4 control-label">Receive Date:</label>
        <div class="col-sm-8">
            <input type="date" class="form-control" id="ReceiveDate" name="ReceiveDate">
        </div>
    </div>

    <div class="form-group">
        <div class="col-sm-offset-4 col-sm-8">
            <button type="submit" class="btn btn-primary" name="save_receive"><i class="fa fa-save"></i> Submit</button>
        </div>
    </div>
</form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once 'footer.php';
?>
