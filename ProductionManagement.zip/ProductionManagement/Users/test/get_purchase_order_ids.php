<?php

// Connect to the database (replace placeholders with actual details)
$mysqli = new mysqli('localhost', 'root', "", 'tms');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Fetch Purchase Order IDs from the database
$query = "SELECT PurchaseOrderID FROM purchaseordermanagement";
$result = $mysqli->query($query);

if ($result) {
    $purchaseOrderIds = array();
    while ($row = $result->fetch_assoc()) {
        $purchaseOrderIds[] = $row['PurchaseOrderID'];
    }

    echo json_encode($purchaseOrderIds);
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
