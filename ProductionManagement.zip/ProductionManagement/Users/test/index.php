<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yarn Receive Management</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Add your custom CSS file if needed -->
</head>

<body>

    <div class="container mt-5">
        <!-- Your PHP code here -->

        <div class="row">
            <div class="col-md-6 offset-md-3">
                <!-- Display success or error message -->
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success" role="alert">
                        <?= $success ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger" role="alert">
                        <?= $error ?>
                    </div>
                <?php endif; ?>

                <form class="form-horizontal" action="yarnReceiveAdding.php" method="POST">
                    <!-- PurchaseOrderID Dropdown -->
                    <div class="form-group">
                        <label for="purchaseOrderId" class="col-sm-4 control-label">Purchase Order:</label>
                        <div class="col-sm-8">
                            <select class="form-control" id="purchaseOrderId" name="purchaseOrderId"
                                onchange="loadProductAndSupplierNames()">
                                <option>Select One</option>
                                <!-- Options will be populated dynamically using JavaScript -->
                            </select>
                        </div>
                    </div>

                    <!-- ProductID Input -->
                    <div class="form-group">
                        <label for="ProductID" class="col-sm-4 control-label">Product:</label>
                        <div class="col-sm-8">
                            <input type="text" id="productName" name="productName" readonly>
                        </div>
                    </div>

                    <!-- SupplierID Input -->
                    <div class="form-group">
                        <label for="SupplierID" class="col-sm-4 control-label">Supplier:</label>
                        <div class="col-sm-8">
                            <input type="text" id="supplierName" name="supplierName" readonly>
                        </div>
                    </div>

                    <!-- ReceivedQuantity Input -->
                    <div class="form-group">
                        <label for="ReceivedQuantity" class="col-sm-4 control-label">Received Quantity:</label>
                        <div class="col-sm-8">
                            <input type="text" class="form-control" id="ReceivedQuantity" name="ReceivedQuantity"
                                placeholder="Enter received quantity">
                        </div>
                    </div>

                    <!-- WeightID Input -->
                    <div class="form-group">
                        <label for="WeightID" class="col-sm-4 control-label">Weight:</label>
                        <div class="col-sm-8">
                            <input type="text" id="weightName" name="weightName" readonly>
                        </div>
                    </div>

                    <!-- ReceiveDate Input -->
                    <div class="form-group">
                        <label for="ReceiveDate" class="col-sm-4 control-label">Receive Date:</label>
                        <div class="col-sm-8">
                            <input type="date" class="form-control" id="ReceiveDate" name="ReceiveDate">
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="col-sm-offset-4 col-sm-8">
                            <button type="submit" class="btn btn-primary" name="save_receive"><i
                                    class="fa fa-save"></i> Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and other scripts if needed -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.3/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Your existing scripts.js -->
    <script src="scripts.js"></script>

</body>

</html>
