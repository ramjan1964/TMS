<?php

// Connect to the database (replace placeholders with actual details)
$mysqli = new mysqli('localhost', 'root', "", 'tms');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Get PurchaseOrderId from the URL
$purchaseOrderId = $_GET['purchaseOrderId'];

// Fetch additional information based on the selected PurchaseOrderID
$query = "SELECT pm.ProductName, s.SupplierName, w.WeightName 
          FROM purchaseordermanagement pom
          JOIN productmanagement pm ON pom.ProductID = pm.ProductID
          JOIN suppliers s ON pom.SupplierID = s.SupplierID
          JOIN weightunitmanagement w ON pom.WeightID = w.WeightID
          WHERE pom.PurchaseOrderID = '$purchaseOrderId'";

$result = $mysqli->query($query);

if ($result) {
    $data = $result->fetch_assoc();
    echo json_encode($data);
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
