document.addEventListener('DOMContentLoaded', function () {
    // Fetch PurchaseOrderID options from the server (you need to implement this)
    // and populate the dropdown list

    // Example:
    fetch('get_purchase_order_ids.php')
        .then(response => response.json())
        .then(data => {
            const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
            data.forEach(purchaseOrder => {
                const option = document.createElement('option');
                option.value = purchaseOrder['PurchaseOrderID'];
                option.text = purchaseOrder['PurchaseOrderID'];
                purchaseOrderIdSelect.add(option);
            });
        });
});

function loadProductAndSupplierNames() {
    const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
    const selectedOption = purchaseOrderIdSelect.options[purchaseOrderIdSelect.selectedIndex];
    
    // Fetch additional information based on the selected PurchaseOrderID
    fetch('get_purchase_order_info.php?purchaseOrderId=' + selectedOption.value)
        .then(response => response.json())
        .then(data => {
            // Set the values in respective fields
            document.getElementById('productName').value = data.productName;
            document.getElementById('supplierName').value = data.supplierName;
            document.getElementById('weightName').value = data.weightName;
        });
}
