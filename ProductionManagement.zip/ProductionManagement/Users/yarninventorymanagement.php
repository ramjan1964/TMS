<?php
// Include necessary files
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    $requiredFields = ['ReceiveYarnId', 'ProductID', 'StorageLocationID', 'QuantityInStock'];

    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field])) {
            $error = "Error: The field '$field' is not set.";
            break;  // Stop the loop if any required field is not set
        }
    }

    if (empty($error)) {
        // Get data from the form
        $ReceiveYarnId = $_POST['ReceiveYarnId'];
        $ProductID = $_POST['ProductID'];
        $StorageLocationID = $_POST['StorageLocationID'];
        $QuantityInStock = $_POST['QuantityInStock'];

        // Fetch total receive quantity from yarnreceivemanagement table
        $sqlReceiveQty = "SELECT ReceivedQuantity FROM yarnreceivemanagement WHERE ReceiveYarnId = '$ReceiveYarnId'";
        $resultReceiveQty = $conn->query($sqlReceiveQty);

        if ($resultReceiveQty && $resultReceiveQty->num_rows > 0) {
            $rowReceiveQty = $resultReceiveQty->fetch_assoc();
            $TotalReceiveQty = $rowReceiveQty['ReceivedQuantity'];

            // Insert data into the database
            $sql = "INSERT INTO yarninventorymanagement (ReceiveYarnId, ProductID, StorageLocationID, QuantityInStock) 
                    VALUES ('$ReceiveYarnId', '$ProductID', '$StorageLocationID', '$QuantityInStock'";

            if ($conn->query($sql) === TRUE) {
                $success = "Yarn inventory updated successfully!";
            } else {
                $error = "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            $error = "Error fetching total receive quantity.";
        }
    } else {
        $error = "Please fill in all the required fields";
    }
}
?>

<!-- Content for yarninventorymanagement.php -->
<div class="content">
    <!-- content HEADER -->
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Yarn Inventory Management</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <h4 class="section-subtitle"><b>Yarn Inventory</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

                                <!-- ReceiveYarnId Dropdown -->
                                <div class="form-group">
                                    <label for="ReceiveYarnId" class="col-sm-4 control-label">Receive Yarn ID:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="ReceiveYarnId" name="ReceiveYarnId" onchange="updateTotalReceiveQty()">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch receive yarn IDs from the database
                                            $sqlReceiveYarns = "SELECT ReceiveYarnId FROM yarnreceivemanagement";
                                            $resultReceiveYarns = $conn->query($sqlReceiveYarns);

                                            if ($resultReceiveYarns && $resultReceiveYarns->num_rows > 0) {
                                                while ($rowReceiveYarn = $resultReceiveYarns->fetch_assoc()) {
                                                    echo '<option value="' . $rowReceiveYarn['ReceiveYarnId'] . '">' . $rowReceiveYarn['ReceiveYarnId'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No receive yarns available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- ProductID Dropdown -->
                                <div class="form-group">
                                    <label for="ProductID" class="col-sm-4 control-label">Product:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="ProductID" name="ProductID">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch products from the database
                                            $sqlProducts = "SELECT ProductID, ProductName FROM yarnreceivemanagement";
                                            $resultProducts = $conn->query($sqlProducts);

                                            if ($resultProducts && $resultProducts->num_rows > 0) {
                                                while ($rowProduct = $resultProducts->fetch_assoc()) {
                                                    echo '<option value="' . $rowProduct['ProductID'] . '">' . $rowProduct['ProductName'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No products available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- StorageLocationID Dropdown -->
                                <div class="form-group">
                                    <label for="StorageLocationID" class="col-sm-4 control-label">Storage Location:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="StorageLocationID" name="StorageLocationID">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch storage locations from the database
                                            $sqlStorageLocations = "SELECT LocationID, LocationName FROM storagelocations";
                                            $resultStorageLocations = $conn->query($sqlStorageLocations);

                                            if ($resultStorageLocations && $resultStorageLocations->num_rows > 0) {
                                                while ($rowStorageLocation = $resultStorageLocations->fetch_assoc()) {
                                                    echo '<option value="' . $rowStorageLocation['LocationID'] . '">' . $rowStorageLocation['LocationName'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No storage locations available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- QuantityInStock Input -->
                                <div class="form-group">
                                    <label for="QuantityInStock" class="col-sm-4 control-label">Quantity In Stock:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="QuantityInStock" name="QuantityInStock" placeholder="Enter quantity in stock">
                                    </div>
                                </div>

                                <!-- TotalReceiveQty (ReadOnly Input) -->
                                <div class="form-group">
                                    <label for="TotalReceiveQty" class="col-sm-4 control-label">Total Receive Qty:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="TotalReceiveQty" name="TotalReceiveQty" readonly>
                                    </div>
                                </div>

                                <!-- AlreadyStoredQty (Hidden Input) -->
                                <input type="hidden" id="AlreadyStoredQty" name="AlreadyStoredQty">

                                <!-- YetToStoreQty (ReadOnly Input) -->
                                <div class="form-group">
                                    <label for="YetToStoreQty" class="col-sm-4 control-label">Yet to Store Qty:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="YetToStoreQty" name="YetToStoreQty" readonly>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_inventory"><i class="fa fa-save"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
// Include footer
require_once 'footer.php';
?>
