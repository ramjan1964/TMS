<?php
// get_products.php

// Include necessary files
require_once '../db_config.php';

// Check if purchaseOrderId is set
if(isset($_POST['PurchaseOrderID'])){
    $PurchaseOrderID = $_POST['PurchaseOrderID'];
    
    // Fetch products based on the selected Purchase Order
    $sql = "SELECT ProductID, ProductName FROM productmanagement WHERE PurchaseOrderID = $PurchaseOrderID";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        // Build options for Product dropdown
        $options = '<option>Select One</option>';
        while ($row = $result->fetch_assoc()) {
            $options .= '<option value="' . $row['ProductID'] . '">' . $row['ProductName'] . '</option>';
        }
        echo $options;
    } else {
        echo '<option value="" disabled>No products available</option>';
    }
}
?>
