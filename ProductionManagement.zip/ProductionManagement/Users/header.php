
<!doctype html>
<html lang="en" class="fixed left-sidebar-top">


<!-- Mirrored from myiideveloper.com/helsinki/last-version/helsinki_green-dark/src/forms_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 05 Mar 2019 13:05:56 GMT -->

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>PMS</title>
   
    <!--load progress bar-->
    <script src="../../vendor/pace/pace.min.js"></script>
    <link href="../../vendor/pace/pace-theme-minimal.css" rel="stylesheet" />
    <!--BASIC css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../../vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../../vendor/fontawesome/css/all.min.css">
     <!-- Include Font Awesome CSS -->
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" integrity="sha384-GLhlTQ8iK7ZF7a8+zRabIfX3WUTFK3gy1jAIZhetx4iS4U5/sWz4+u95q6L4N2M" crossorigin="anonymous">
    <link rel="stylesheet" href="../../vendor/animate.css/animate.css">
    <!--SECTION css-->
    <!-- ========================================================= -->
    <!--TEMPLATE css-->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../../stylesheets/css/style.css">
    <!--dataTable-->
    <link rel="stylesheet" href="../../vendor/data-table/media/css/dataTables.bootstrap.min.css">
</head>

<body>
    <div class="wrap">
        <!-- page HEADER -->
        <!-- ========================================================= -->
        <div class="page-header">
            <!-- LEFTSIDE header -->
            <div class="leftside-header">
                <div class="logo">
                    <a href="index.html" class="on-click">
                        <h3>PMS</h3>
                    </a>
                </div>
                <div id="menu-toggle" class="visible-xs toggle-left-sidebar" data-toggle-class="left-sidebar-open"
                    data-target="html">
                    <i class="fa fa-bars" aria-label="Toggle sidebar"></i>
                </div>
            </div>
            <!-- RIGHTSIDE header -->
            <div class="rightside-header">
                <div class="header-middle"></div>

                <!--USER HEADERBOX -->
                <div class="header-section" id="user-headerbox">
                    <div class="user-header-wrap">
                        <div class="user-photo">
                            <img alt="profile photo" src="../images/avatar/user.jpg" />
                        </div>
                        <div class="user-info">
                            <span class="user-name">Ramjan</span>
                            <span class="user-profile">Admin</span>
                        </div>
                        <i class="fa fa-plus icon-open" aria-hidden="true"></i>
                        <i class="fa fa-minus icon-close" aria-hidden="true"></i>
                    </div>
                    <div class="user-options dropdown-box">
                        <div class="drop-content basic">
                            <ul>
                                <li> <a href="log_out.php"><i class="fa fa-user" aria-hidden="true"></i>
                                        Profile</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="header-separator"></div>
                <!--Log out -->
                <div class="header-section">
                    <a href="pages_sign-in.php" data-toggle="tooltip" data-placement="left" title="Logout"><i
                            class="fa fa-sign-out log-out" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
        <div class="page-body">
            <!-- LEFT SIDEBAR -->
            <!-- ========================================================= -->
            <div class="left-sidebar">
                <!-- left sidebar HEADER -->
                <div class="left-sidebar-header">
                    <div class="left-sidebar-title">Navigation</div>
                    <div class="left-sidebar-toggle c-hamburger c-hamburger--htla hidden-xs"
                        data-toggle-class="left-sidebar-collapsed" data-target="html">
                        <span></span>
                    </div>
                </div>
                <!-- NAVIGATION -->
                <!-- ========================================================= -->
                <div id="left-nav" class="nano">
                    <div class="nano-content">
                        <nav>
                            <ul class="nav nav-left-lines" id="main-nav">
                                <!-- HOME -->
                                <li class="<?= $page == 'index.php' ? 'active-item' : '' ?>"><a href="index.php"><i
                                            class="fa fa-home" aria-hidden="true"></i><span>Dashboard</span></a></li>
                               
                                          <!-- Purchase Order -->
<li class="has-child-item <?= (in_array($page, ['../purchase_order/PurchaseOrderMgt.php', '../purchase_order/PurchaseOrderAdding.php'])) ? 'open-item active-item' : 'close-item' ?>">
    <a href="#">
        <i class="fa fa-cart-shopping" aria-hidden="true"></i>
        <span>Purchase Order</span>
    </a>
    <ul class="nav child-nav level-1">
        <li class="<?= ($page == '../purchaseOrder/PurchaseOrderAdding.php') ? 'active-item' : '' ?>">
            <a href="../purchaseOrder/PurchaseOrderAdding.php">
                <span><i class="fa fa-cart-plus" aria-hidden="true">&nbsp;&nbsp;</i>Add Purchase Order</span>
            </a>
        </li>
        <li class="<?= ($page == '../purchaseOrder/PurchaseOrderMgt.php') ? 'active-item' : '' ?>">
            <a href="../purchaseOrder/PurchaseOrderMgt.php">
                <span><i class="fa fa-gear" aria-hidden="true">&nbsp;&nbsp;</i>Manage Purchase Order</span>
            </a>
        </li>
    </ul>
</li>

<!-- Yarn Receive -->
<li class="has-child-item <?= (in_array($page, ['../yarnReceives/yarnReceiveMgt.php', '../yarnReceives/yarnReceiveAdding.php'])) ? 'open-item active-item' : 'close-item' ?>">
    <a href="#">
        <i class="fa fa-box" aria-hidden="true"></i>
        <span>Yarn Receive</span>
    </a>
    <ul class="nav child-nav level-1">
        <li class="<?= ($page == '../yarnReceives/yarnReceiveAdding.php') ? 'active-item' : '' ?>">
            <a href="../yarnReceives/yarnReceiveAdding.php">
            <i class="fa-solid fa-calendar-plus" aria-hidden="true"></i> <span>Yarn Receiving</span>
            </a>
        </li>
        <li class="<?= ($page == '../yarnReceives/yarnReceiveMgt.php') ? 'active-item' : '' ?>">
            <a href="../yarnReceives/yarnReceiveMgt.php">
            <span><i class="fa fa-gear" aria-hidden="true">&nbsp;&nbsp;</i>Manage yarnReceives</span>
            </a>
        </li>
    </ul>
</li>


                                <li
                                    class="has-child-item <?= ($page == 'manage_program.php' || $page == 'program_add.php') ? 'open-item active-item' : 'close-item' ?>">
                                    <a><i class="fa fa-table" aria-hidden="true"></i><span>Knit Dyeing Program</span></a>
                                    <ul class="nav child-nav level-1" style="">
                                        <li class="<?= $page == 'program_add.php' ? 'active-item' : '' ?>"><a
                                                href="program_add.php">Add Fabric Program List</a></li>
                                                <li class="<?= $page == 'manage_program.php' ? 'active-item' : '' ?>"><a
                                                href="manage_program.php">Fabric Program</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>


            </div>
</div>