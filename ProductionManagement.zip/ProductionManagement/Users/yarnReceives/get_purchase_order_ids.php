<?php
// Connect to the database (replace placeholders with actual details)
$mysqli = new mysqli('localhost', 'root', "", 'tms');
require_once '../../db_config.php';

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Fetch Purchase Order IDs and related information from the database
$query = "SELECT pom.PurchaseOrderID, pm.ProductName, s.SupplierName, w.WeightName, pom.PurchaseOrderQuantity 
          FROM purchaseordermanagement pom
          JOIN productmanagement pm ON pom.ProductID = pm.ProductID
          JOIN suppliers s ON pom.SupplierID = s.SupplierID
          JOIN weightunitmanagement w ON pom.WeightID = w.WeightID";

$result = $mysqli->query($query);

if ($result) {
    $purchaseOrders = array();
    while ($row = $result->fetch_assoc()) {
        // Calculate the TotalReceivedQuantity
        $query2 = "SELECT SUM(ReceivedQuantity) AS TotalReceivedQuantity,PurchaseOrderID 
          FROM yarnreceivemanagement 
          WHERE PurchaseOrderID = '".$row['PurchaseOrderID']."'";
        $result2 = $mysqli->query($query2);
        if ($result2 && $result2->num_rows > 0) {
            $receivedQuantityRow = $result2->fetch_assoc();
            $totalReceivedQuantity = $receivedQuantityRow['TotalReceivedQuantity'];
        } else {
            $totalReceivedQuantity = 0;
        }
    
        // Calculate the RemainingReceiveQuantity
        $remainingReceiveQuantity = $row['PurchaseOrderQuantity'] - $totalReceivedQuantity;
    
        // Add the calculated quantities to the purchase order data array
        $purchaseOrders[] = array(
            'PurchaseOrderID' => $row['PurchaseOrderID'],
            'ProductName' => $row['ProductName'],
            'SupplierName' => $row['SupplierName'],
            'WeightName' => $row['WeightName'],
            'PurchaseOrderQuantity' => $row['PurchaseOrderQuantity'],
            'TotalReceivedQuantity' => $totalReceivedQuantity,
            'RemainingReceiveQuantity' => $remainingReceiveQuantity
        );
    }

    echo json_encode($purchaseOrders);
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
