<?php
require_once '../header.php';
require_once '../../db_config.php';
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-shopping-cart" aria-hidden="true"></i><a href="javascript:avoi(0)">Yarn Receive
                        Management</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">

            <!-- Yarn Receive Management List -->
            <div class="panel">

                <div class="panel-content">
                    <h5>Yarn Receive Management List</h5>
                    <div class="table-responsive">
                        <table id="basic-table"
                            class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered"
                            cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">Receive Yarn ID</th>
                                    <th style="text-align: center;">Purchase Order ID</th>
                                    <th style="text-align: center;">Product Name</th>
                                    <th style="text-align: center;">Supplier Name</th>
                                    <th style="text-align: center;">Received Quantity</th>
                                    <th style="text-align: center;">Weight Name</th>
                                    <th style="text-align: center;">Receive Date</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch Yarn Receive Management data with product name, supplier name, and weight name
                                $yarnReceiveSql = "SELECT yrm.*, pm.productName, s.supplierName, wm.WeightName
                                    FROM yarnreceivemanagement yrm
                                    JOIN productmanagement pm ON yrm.ProductID = pm.ProductID
                                    JOIN suppliers s ON yrm.SupplierID = s.SupplierID
                                    JOIN weightunitmanagement wm ON yrm.WeightID = wm.WeightID";

                                $yarnReceiveResult = $conn->query($yarnReceiveSql);
                                if ($yarnReceiveResult->num_rows > 0): ?>
                                    <?php while ($yarnReceiveRow = $yarnReceiveResult->fetch_assoc()): ?>
                                        <tr>
                                            <td style="text-align: center;">
                                                <?= $yarnReceiveRow['ReceiveYarnId'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['PurchaseOrderID'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['productName'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['supplierName'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['ReceivedQuantity'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['WeightName'] ?>
                                            </td>
                                            <td>
                                                <?= $yarnReceiveRow['ReceiveDate'] ?>
                                            </td>

                                            <td>
                                                <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal'
                                                    data-target='#view-modal-<?= $yarnReceiveRow['ReceiveYarnId'] ?>'><i
                                                        class='fa fa-eye'></i></a>
                                                        <a href='updateyarn.php?receiveYarnId=<?= $yarnReceiveRow['ReceiveYarnId'] ?>' class='btn btn-warning'>
                                                                    <i class='fa fa-pencil'></i>
                                                                </a>
                                                                <a href='yarnLocation.php?locationYarnId=<?= $yarnReceiveRow['ReceiveYarnId'] ?>' class='btn btn-warning'>
                                                                    <i class='fa fa-plus'></i>
                                                                </a>
                                                        <!-- Add other actions as needed -->

                                                    </td>

                                                </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="8">No yarn receive records found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- End Yarn Receive Management List -->
            </div>
        </div>

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>

<?php
// Fetch Yarn Receive Management Data for modals
$yarnReceiveResult = $conn->query($yarnReceiveSql);
if ($yarnReceiveResult->num_rows > 0): ?>
    <?php while ($yarnReceiveRow = $yarnReceiveResult->fetch_assoc()): ?>
        <!-- View Modal -->
        <div class="modal fade" id="view-modal-<?= $yarnReceiveRow['ReceiveYarnId'] ?>" tabindex="-1" role="dialog"
            aria-labelledby="view-modal-label">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header state modal-info">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i>Yarn Receive Information:</h4>
                    </div>
                    <table class="table table-bordered">
                        <tr>
                            <th style="text-align: center;">Receive Yarn ID</th>
                            <th>Purchase Order ID</th>
                            <th>Product Name</th>
                            <th>Supplier Name</th>
                            <th>Received Quantity</th>
                            <th>Weight Name</th>
                            <th>Receive Date</th>
                        </tr>
                        <tr>
                            <td style="text-align: center;">
                                <?= $yarnReceiveRow['ReceiveYarnId'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['PurchaseOrderID'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['productName'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['supplierName'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['ReceivedQuantity'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['WeightName'] ?>
                            </td>
                            <td>
                                <?= $yarnReceiveRow['ReceiveDate'] ?>
                            </td>
                        </tr>
                    </table>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>






    <?php endwhile; else: endif;
require_once '../footer.php';
?>