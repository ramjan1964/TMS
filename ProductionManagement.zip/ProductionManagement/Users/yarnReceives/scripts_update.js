document.addEventListener('DOMContentLoaded', function () {
    // Fetch PurchaseOrderID options from the server (you need to implement this)
    // and populate the dropdown list

    // Example:
    fetch('get_purchase_order_ids.php')
        .then(response => response.json())
        .then(data => {
            const purchaseOrderIdSelect = document.getElementById('edit_purchase_order_id');
            data.forEach(purchaseOrder => {
                const option = document.createElement('option');
                option.value = purchaseOrder['PurchaseOrderID'];
                option.setAttribute('data-product', purchaseOrder['ProductName']);
                option.setAttribute('data-supplier', purchaseOrder['SupplierName']);
                option.setAttribute('data-weight', purchaseOrder['WeightName']);
                option.setAttribute('data-quantity', purchaseOrder['PurchaseOrderQuantity']);
                option.setAttribute('data-total-received', purchaseOrder['TotalReceivedQuantity']);
                option.setAttribute('data-remaining-receive', purchaseOrder['RemainingReceiveQuantity']);
                option.text = purchaseOrder['PurchaseOrderID'];
                purchaseOrderIdSelect.add(option);
            });
        });
});

function loadProductAndSupplierNames() {
    const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
    const selectedOption = purchaseOrderIdSelect.options[purchaseOrderIdSelect.selectedIndex];
    
    // Set the values in respective fields
    document.getElementById('productName').value = selectedOption.getAttribute('data-product');
    document.getElementById('supplierName').value = selectedOption.getAttribute('data-supplier');
    document.getElementById('PurchaseOrderQuantity').value = selectedOption.getAttribute('data-quantity');
    document.getElementById('ReceivedQuantity').value = ''; // Reset received quantity
    document.getElementById('WeightName').value = selectedOption.getAttribute('data-weight'); // Update to 'WeightName'
}

function loadDataForUpdate() {
    const purchaseOrderIdSelect = document.getElementById('edit_purchase_order_id');
    const selectedOption = purchaseOrderIdSelect.options[purchaseOrderIdSelect.selectedIndex];
    
    // Set the values in respective fields
    document.getElementById('edit_product_name').value = selectedOption.getAttribute('data-product');
    document.getElementById('edit_supplier_name').value = selectedOption.getAttribute('data-supplier');
    document.getElementById('edit_purchase_order_quantity').value = selectedOption.getAttribute('data-quantity');
    document.getElementById('edit_total_received_quantity').value = selectedOption.getAttribute('data-total-received');
    document.getElementById('edit_remaining_receive_quantity').value = selectedOption.getAttribute('data-remaining-receive');
    document.getElementById('edit_received_quantity').value = ''; // Reset received quantity
    document.getElementById('edit_weight_name').value = selectedOption.getAttribute('data-weight');
}
