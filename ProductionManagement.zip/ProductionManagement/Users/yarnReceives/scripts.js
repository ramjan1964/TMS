document.addEventListener('DOMContentLoaded', function () {
    // Fetch PurchaseOrderID options from the server (you need to implement this)
    // and populate the dropdown list

    // Example:
    fetch('get_purchase_order_ids.php')
        .then(response => response.json())
        .then(data => {
            const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
            data.forEach(purchaseOrder => {
                const option = document.createElement('option');
                option.value = purchaseOrder['PurchaseOrderID'];
                option.setAttribute('data-product', purchaseOrder['ProductName']);
                option.setAttribute('data-supplier', purchaseOrder['SupplierName']);
                option.setAttribute('data-weight', purchaseOrder['WeightName']);
                option.setAttribute('data-quantity', purchaseOrder['PurchaseOrderQuantity']);
                option.text = purchaseOrder['PurchaseOrderID'];
                purchaseOrderIdSelect.add(option);
            });
        });
});

function loadProductAndSupplierNames() {
    const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
    const selectedOption = purchaseOrderIdSelect.options[purchaseOrderIdSelect.selectedIndex];
    
    // Set the values in respective fields
    document.getElementById('productName').value = selectedOption.getAttribute('data-product');
    document.getElementById('supplierName').value = selectedOption.getAttribute('data-supplier');
    document.getElementById('PurchaseOrderQuantity').value = selectedOption.getAttribute('data-quantity');
    document.getElementById('ReceivedQuantity').value = ''; // Reset received quantity
    document.getElementById('WeightName').value = selectedOption.getAttribute('data-weight'); // Update to 'WeightName'

    // Display TotalReceivedQuantity and RemainingReceiveQuantity
    document.getElementById('TotalReceivedQuantity').value = selectedOption.getAttribute('data-total-received');
    document.getElementById('RemainingReceiveQuantity').value = selectedOption.getAttribute('data-remaining-receive');
}

