<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Purchase Order Management</title>
  <!-- Include DataTables CSS and JS -->
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
  <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.2.min.js"></script>
  <script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
</head>
<body>

<table id="purchaseOrderTable" class="display">
  <thead>
    <tr>
      <th>PurchaseOrderID</th>
      <th>SupplierID</th>
      <th>ProductID</th>
      <th>PurchaseOrderQuantity</th>
      <th>WeightID</th>
      <th>Price</th>
      <th>Amount</th>
      <th>CurrencyID</th>
      <th>PurchaseOrderDate</th>
    </tr>
  </thead>
  <!-- DataTable headers here -->
</table>

<!-- Modal for updating data -->
<div id="updateModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeUpdateModal()">&times;</span>
    <h2>Update Purchase Order</h2>
    <form id="updateForm">
      <label for="purchaseOrderQuantity">Purchase Order Quantity:</label>
      <input type="text" id="purchaseOrderQuantity" name="purchaseOrderQuantity" required value="">
      
      <label for="price">Price:</label>
      <input type="text" id="price" name="price" required value="">

      <label for="amount">Amount:</label>
      <input type="text" id="amount" name="amount" required value="">

      <!-- Add more fields as needed -->

      <button type="button" onclick="updateData()">Update</button>
    </form>
  </div>
</div>

<script>
  $(document).ready(function() {
    // Initialize DataTable
    $('#purchaseOrderTable').DataTable({
      // DataTable configuration
      "ajax": "get_purchase_order_data.php", // Server-side script to fetch data
      "columns": [
        { "data": "PurchaseOrderID" },
        { "data": "SupplierID" },
        { "data": "ProductID" },
        { "data": "PurchaseOrderQuantity" },
        { "data": "WeightID" },
        { "data": "Price" },
        { "data": "Amount" },
        { "data": "CurrencyID" },
        { "data": "PurchaseOrderDate" }
      ]
    });

    // Add click event listener to rows
    $('#purchaseOrderTable tbody').on('click', 'tr', function () {
      // Open modal with data for the selected row
      var data = $('#purchaseOrderTable').DataTable().row(this).data();
      openUpdateModal(data);
    });
  });

  function openUpdateModal(data) {
    // Populate modal with data
    document.getElementById("purchaseOrderQuantity").value = data.PurchaseOrderQuantity;
    document.getElementById("price").value = data.Price;
    document.getElementById("amount").value = data.Amount;
    // Update other fields as needed
    // Show/update modal content
    document.getElementById("updateModal").style.display = "block";
  }

  function closeUpdateModal() {
    document.getElementById("updateModal").style.display = "none";
  }

  function updateData() {
    // Implement update logic here
    // You can use AJAX to send updated data to the server
    // After updating, close the modal and refresh the DataTable
    closeUpdateModal();
    $('#purchaseOrderTable').DataTable().ajax.reload();
  }
</script>

</body>
</html>
