<?php
// Fetch data from your database and return as JSON
// Modify this script to suit your database connection and query
// Example: Fetch data using PDO

// ... (Database connection)
// Establish a database connection
$mysqli = new mysqli('localhost', 'root', '', 'tms');

// Check if the connection is successful
if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}
// Fetch data
$query = "SELECT * FROM purchaseordermanagement";
$result = $pdo->query($query);
$data = $result->fetchAll(PDO::FETCH_ASSOC);

// Return data as JSON
echo json_encode(['data' => $data]);
?>
