<?php
require_once '../../db_config.php';
require_once '../header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
  // Check if the required fields are set
$requiredFields = ['SupplierID', 'ProductID', 'PurchaseOrderQuantity', 'WeightID', 'Price', 'Amount', 'CurrencyID', 'PurchaseOrderDate'];

foreach ($requiredFields as $field) {
    if (!isset($_POST[$field])) {
        $error = "Error: The field '$field' is not set.";
        break;  // Stop the loop if any required field is not set
    }
}

if (empty($error)) {
    // Get data from the form
    $SupplierID = $_POST['SupplierID'];
    $ProductID = $_POST['ProductID'];
    $PurchaseOrderQuantity = $_POST['PurchaseOrderQuantity'];
    $WeightID = $_POST['WeightID'];
    $Price = $_POST['Price'];
    $Amount = $_POST['Amount'];
    $CurrencyID = $_POST['CurrencyID'];
    $PurchaseOrderDate = $_POST['PurchaseOrderDate'];

    // Insert data into the database
    $sql = "INSERT INTO PurchaseOrderManagement (SupplierID, ProductID, PurchaseOrderQuantity, WeightID, Price, Amount, CurrencyID, PurchaseOrderDate) 
            VALUES ('$SupplierID', '$ProductID', '$PurchaseOrderQuantity', '$WeightID', '$Price', '$Amount', '$CurrencyID', '$PurchaseOrderDate')";

    if ($conn->query($sql) === TRUE) {
        $success = "Purchase Order added successfully!";
    } else {
        $error = "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    $error = "Please fill in all the required fields";
}

}

?>
<!-- Add this script to update the Amount field -->
<!-- Add this script to update the Amount field -->
<script>
    function updateAmount() {
        // Get the values of Price and Quantity
        var price = parseFloat(document.getElementById('Price').value) || 0;
        var quantity = parseInt(document.getElementById('PurchaseOrderQuantity').value) || 0;

        // Calculate the Amount
        var amount = price * quantity;

        // Update the Amount field
        var amountField = document.getElementById('Amount');
        amountField.value = amount.toFixed(2);

        // Enable the Amount field before form submission
        amountField.removeAttribute('disabled');
    }
</script>


<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Add Purchase Order</a></li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <!-- Rest of your HTML code goes here -->
            <h4 class="section-subtitle"><b>Purchase Order</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Purchase Order</h4>
<!-- SupplierID Dropdown -->
<div class="form-group">
    <label for="SupplierID" class="col-sm-4 control-label">Supplier:</label>
    <div class="col-sm-8">
        <select class="form-control" id="SupplierID" name="SupplierID">
            <option>Select One</option>
            <?php
            // Fetch suppliers from the database
            $sqlSuppliers = "SELECT SupplierID, SupplierName FROM suppliers";
            $resultSuppliers = $conn->query($sqlSuppliers);

            // Check if there are suppliers
            if ($resultSuppliers && $resultSuppliers->num_rows > 0) {
                while ($rowSupplier = $resultSuppliers->fetch_assoc()) {
                    echo '<option value="' . $rowSupplier['SupplierID'] . '">' . $rowSupplier['SupplierName'] . '</option>';
                }
            } else {
                echo '<option value="" disabled>No suppliers available</option>';
            }
            ?>
        </select>
    </div>
</div>


                               <!-- ProductID Dropdown -->
<div class="form-group">
    <label for="ProductID" class="col-sm-4 control-label">Product:</label>
    <div class="col-sm-8">
        <select class="form-control" id="ProductID" name="ProductID">
        <option>Select One</option>
            <?php
            // Fetch products from the database
            $sqlProducts = "SELECT ProductID, ProductName FROM productmanagement";
            $resultProducts = $conn->query($sqlProducts);

            // Check if there are products
            if ($resultProducts && $resultProducts->num_rows > 0) {
                while ($rowProduct = $resultProducts->fetch_assoc()) {
                    echo '<option value="' . $rowProduct['ProductID'] . '">' . $rowProduct['ProductName'] . '</option>';
                }
            } else {
                echo '<option value="" disabled>No products available</option>';
            }
            ?>
        </select>
    </div>
</div>

                           
                              <!-- Price Input -->
<div class="form-group">
    <label for="Price" class="col-sm-4 control-label">Price:</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="Price" name="Price" placeholder="Enter price" oninput="updateAmount()">
    </div>
</div>

                               <!-- WeightID Dropdown -->
<div class="form-group">
    <label for="WeightID" class="col-sm-4 control-label">Weight:</label>
    <div class="col-sm-8">
        <select class="form-control" id="WeightID" name="WeightID">
        <option>Select One</option>
            <?php
            // Fetch weights from the database
            $sqlWeights = "SELECT WeightID, WeightName FROM weightunitmanagement";
            $resultWeights = $conn->query($sqlWeights);

            // Check if there are weights
            if ($resultWeights && $resultWeights->num_rows > 0) {
                while ($rowWeight = $resultWeights->fetch_assoc()) {
                    echo '<option value="' . $rowWeight['WeightID'] . '">' . $rowWeight['WeightName'] . '</option>';
                }
            } else {
                echo '<option value="" disabled>No weights available</option>';
            }
            ?>
        </select>
    </div>
</div>


<!-- PurchaseOrderQuantity Input -->
<div class="form-group">
    <label for="PurchaseOrderQuantity" class="col-sm-4 control-label">Quantity:</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="PurchaseOrderQuantity" name="PurchaseOrderQuantity" placeholder="Enter quantity" oninput="updateAmount()">
    </div>
</div>

<!-- Amount Input (Disabled) -->
<div class="form-group">
    <label for="Amount" class="col-sm-4 control-label">Amount:</label>
    <div class="col-sm-8">
        <input type="text" class="form-control" id="Amount" name="Amount" placeholder="Amount" disabled>
    </div>
</div>




                             <!-- CurrencyID Dropdown -->
<div class="form-group">
    <label for="CurrencyID" class="col-sm-4 control-label">Currency:</label>
    <div class="col-sm-8">
        <select class="form-control" id="CurrencyID" name="CurrencyID">
        <option>Select One</option>
            <?php
            // Fetch currencies from the database
            $sqlCurrencies = "SELECT CurrencyID, CurrencyName FROM currencymanagement";
            $resultCurrencies = $conn->query($sqlCurrencies);

            // Check if there are currencies
            if ($resultCurrencies && $resultCurrencies->num_rows > 0) {
                while ($rowCurrency = $resultCurrencies->fetch_assoc()) {
                    echo '<option value="' . $rowCurrency['CurrencyID'] . '">' . $rowCurrency['CurrencyName'] . '</option>';
                }
            } else {
                echo '<option value="" disabled>No currencies available</option>';
            }
            ?>
        </select>
    </div>
</div>

                                <!-- PurchaseOrderDate Input -->
                                <div class="form-group">
                                    <label for="PurchaseOrderDate" class="col-sm-4 control-label">Order Date:</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" id="PurchaseOrderDate" name="PurchaseOrderDate">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_order"><i class="fa fa-save"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once '../footer.php';
?>
