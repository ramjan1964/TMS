<?php
require_once '../../db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get values from the form
    $purchaseOrderId = $_POST['purchase_order_id'];
    $supplierName = $_POST['edit_supplier'];
    $productName = $_POST['edit_product'];
    $WeightName = $_POST['edit_WeightName'];
    $purchaseOrderQuantity = $_POST['edit_PurchaseOrderQuantity'];
    $amount = $_POST['edit_Amount'];
    $currencyName = $_POST['edit_CurrencyName'];
    $purchaseOrderDate = $_POST['edit_PurchaseOrderDate'];

    // TODO: Validate and sanitize user inputs

    // Get supplierId from supplierManagement table
$supplierIdSql = "SELECT SupplierID FROM suppliers WHERE SupplierName = ?";
$supplierIdStmt = $conn->prepare($supplierIdSql);
$supplierIdStmt->bind_param("s", $supplierName); // <-- Corrected variable name
$supplierIdStmt->execute();
$supplierIdResult = $supplierIdStmt->get_result();
$supplierIdRow = $supplierIdResult->fetch_assoc();
$supplierId = $supplierIdRow['SupplierID']; // <-- Corrected variable name

// Get productId from productManagement table
$productIdSql = "SELECT ProductID FROM productmanagement WHERE ProductName = ?";
$productIdStmt = $conn->prepare($productIdSql);
$productIdStmt->bind_param("s", $productName);
$productIdStmt->execute();
$productIdResult = $productIdStmt->get_result();
$productIdRow = $productIdResult->fetch_assoc();
$productId = $productIdRow['ProductID'];

// Get WeightID from WeightManagement table
$weightIdSql = "SELECT WeightID FROM weightunitmanagement WHERE WeightName = ?";
$weightIdStmt = $conn->prepare($weightIdSql);
$weightIdStmt->bind_param("s", $WeightName);
$weightIdStmt->execute();
$weightIdResult = $weightIdStmt->get_result();
$weightIdRow = $weightIdResult->fetch_assoc();
$weightId = $weightIdRow['WeightID'];

// Get CurrencyID from CurrencyManagement table
$currencyIdSql = "SELECT CurrencyID FROM currencymanagement WHERE CurrencyName = ?";
$currencyIdStmt = $conn->prepare($currencyIdSql);
$currencyIdStmt->bind_param("s", $currencyName);
$currencyIdStmt->execute();
$currencyIdResult = $currencyIdStmt->get_result();
$currencyIdRow = $currencyIdResult->fetch_assoc();
$currencyId = $currencyIdRow['CurrencyID'];


    // Update the purchase order data in the database using prepared statement
    $updateSql = "UPDATE purchaseordermanagement 
                  SET supplierId = ?, 
                      productId = ?, 
                      WeightID = ?, 
                      PurchaseOrderQuantity = ?, 
                      Amount = ?, 
                      CurrencyID = ?, 
                      PurchaseOrderDate = ?
                  WHERE PurchaseOrderID = ?";

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($updateSql);
    $stmt->bind_param("ssssdssi", $supplierId, $productId, $weightId, $purchaseOrderQuantity, $amount, $currencyId, $purchaseOrderDate, $purchaseOrderId);


    if ($stmt->execute()) {
        // Redirect to the page where the update was initiated
        header("Location: purchaseOrderMgt.php");
        exit();
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    // Close the prepared statements
    $stmt->close();
    $supplierIdStmt->close();
    $productIdStmt->close();
    $weightIdStmt->close();
    $currencyIdStmt->close();
} else {
    // Redirect to the page where the update was initiated if accessed directly without POST data
    header("Location: purchaseOrderMgt.php");
    exit();
}
?>
