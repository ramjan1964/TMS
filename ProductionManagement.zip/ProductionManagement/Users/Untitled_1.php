<?php
// Include necessary files
require_once '../db_config.php';
require_once 'header.php';

// Initialize variables
$success = $error = '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the required fields are set
    $requiredFields = ['PurchaseOrderID', 'ProductID', 'SupplierID', 'ReceivedQuantity', 'WeightID', 'ReceiveDate'];

    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field])) {
            $error = "Error: The field '$field' is not set.";
            break;  // Stop the loop if any required field is not set
        }
    }

    if (empty($error)) {
        // Get data from the form
        $PurchaseOrderID = $_POST['PurchaseOrderID'];
        $ProductID = $_POST['ProductID'];
        $SupplierID = $_POST['SupplierID'];
        $ReceivedQuantity = $_POST['ReceivedQuantity'];
        $WeightID = $_POST['WeightID'];
        $ReceiveDate = $_POST['ReceiveDate'];

        // Insert data into the database
        $sql = "INSERT INTO yarnreceivemanagement (PurchaseOrderID, ProductID, SupplierID, ReceivedQuantity, WeightID, ReceiveDate) 
                VALUES ('$PurchaseOrderID', '$ProductID', '$SupplierID', '$ReceivedQuantity', '$WeightID', '$ReceiveDate')";

        if ($conn->query($sql) === TRUE) {
            $success = "Yarn received successfully!";
        } else {
            $error = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $error = "Please fill in all the required fields";
    }
}
?>

<!-- Content for yarn_receive.php -->
<div class="content">
    <!-- content HEADER -->
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Yarn Receive Management</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <h4 class="section-subtitle"><b>Yarn Receive</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">

                                <!-- PurchaseOrderID Dropdown -->
                                <div class="form-group">
                                    <label for="PurchaseOrderID" class="col-sm-4 control-label">Purchase Order:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="PurchaseOrderID" name="PurchaseOrderID">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch purchase orders from the database
                                            $sqlPurchaseOrders = "SELECT PurchaseOrderID FROM PurchaseOrderManagement";
                                            $resultPurchaseOrders = $conn->query($sqlPurchaseOrders);

                                            if ($resultPurchaseOrders && $resultPurchaseOrders->num_rows > 0) {
                                                while ($rowPurchaseOrder = $resultPurchaseOrders->fetch_assoc()) {
                                                    echo '<option value="' . $rowPurchaseOrder['PurchaseOrderID'] . '">' . $rowPurchaseOrder['PurchaseOrderID'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No purchase orders available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- ProductID Dropdown -->
                                <div class="form-group">
                                    <label for="ProductID" class="col-sm-4 control-label">Product:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="ProductID" name="ProductID">
                                            <option>Select One</option>
                                            <!-- Options will be dynamically added using JavaScript -->
                                        </select>
                                    </div>
                                </div>

                               <!-- SupplierID Dropdown -->
                               <div class="form-group">
                                    <label for="SupplierID" class="col-sm-4 control-label">Supplier:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="SupplierID" name="SupplierID">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch suppliers from the database
                                            $sqlSuppliers = "SELECT SupplierID, SupplierName FROM suppliers";
                                            $resultSuppliers = $conn->query($sqlSuppliers);

                                            if ($resultSuppliers && $resultSuppliers->num_rows > 0) {
                                                while ($rowSupplier = $resultSuppliers->fetch_assoc()) {
                                                    echo '<option value="' . $rowSupplier['SupplierID'] . '">' . $rowSupplier['SupplierName'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No suppliers available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                 <!-- ReceivedQuantity Input -->
                                 <div class="form-group">
                                    <label for="ReceivedQuantity" class="col-sm-4 control-label">Received Quantity:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ReceivedQuantity" name="ReceivedQuantity" placeholder="Enter received quantity">
                                    </div>
                                </div>

                                <!-- WeightID Dropdown -->
                                <div class="form-group">
                                    <label for="WeightID" class="col-sm-4 control-label">Weight:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="WeightID" name="WeightID">
                                            <option>Select One</option>
                                            <?php
                                            // Fetch weights from the database
                                            $sqlWeights = "SELECT WeightID, WeightName FROM weightunitmanagement";
                                            $resultWeights = $conn->query($sqlWeights);

                                            if ($resultWeights && $resultWeights->num_rows > 0) {
                                                while ($rowWeight = $resultWeights->fetch_assoc()) {
                                                    echo '<option value="' . $rowWeight['WeightID'] . '">' . $rowWeight['WeightName'] . '</option>';
                                                }
                                            } else {
                                                echo '<option value="" disabled>No weights available</option>';
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>

                                <!-- ReceiveDate Input -->
                                <div class="form-group">
                                    <label for="ReceiveDate" class="col-sm-4 control-label">Receive Date:</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" id="ReceiveDate" name="ReceiveDate">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_receive"><i class="fa fa-save"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Add the script section at the end of the file -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script>
$(document).ready(function(){
    // Attach change event listener to PurchaseOrderID dropdown
    $('#PurchaseOrderID').on('change', function(){
        var PurchaseOrderID = $(this).val();
        
        // Debugging statement
        console.log('Purchase Order ID selected:', PurchaseOrderID);

        // Fetch products based on the selected Purchase Order
        $.ajax({
            type: 'POST',
            url: 'get_products.php',
            data: { PurchaseOrderID: PurchaseOrderID },
            success: function(response){
                // Debugging statement
                console.log('AJAX response:', response);

                // Update the Product dropdown options with the fetched products
                $('#ProductID').html(response);
            },
            error: function(xhr, status, error) {
                // Debugging statement for errors
                console.error('AJAX Error:', status, error);
            }
        });
    });
});

</script>

<?php
// Include footer
require_once 'footer.php';
?>
