<?php
require_once 'header.php';
?>
    <!-- Content for yarnreceivemanagement.php -->
<div class="content">
    <!-- content HEADER -->
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoid(0)">Yarn Receive Management</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-6 col-sm-offset-3">
            <h4 class="section-subtitle"><b>Yarn Receive</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                        <form id="yarnReceiveForm" action="insert_yarn_receive.php" method="post">

                                <!-- PurchaseOrderID Dropdown -->
                                <div class="form-group">
                                    <label for="PurchaseOrderID" class="col-sm-4 control-label">Purchase Order:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="purchaseOrderId" name="purchaseOrderId" onchange="loadProductName()">
                                            <option>Select One</option>
                                            <!-- Options will be populated dynamically using JavaScript -->
                                        </select>
                                    </div>
                                </div>

                                <!-- ProductID Dropdown -->
                                <div class="form-group">
                                    <label for="ProductID" class="col-sm-4 control-label">Product:</label>
                                    <div class="col-sm-8">
                                   
                                    <input type="text" id="productName" name="productName" readonly>

                                    </div>
                                </div>

                                <!-- SupplierID Dropdown -->
                                <div class="form-group">
                                    <label for="SupplierID" class="col-sm-4 control-label">Supplier:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="SupplierID" name="SupplierID">
                                            <option>Select One</option>
                                            <!-- Options will be populated dynamically using JavaScript -->
                                        </select>
                                    </div>
                                </div>

                                <!-- ReceivedQuantity Input -->
                                <div class="form-group">
                                    <label for="ReceivedQuantity" class="col-sm-4 control-label">Received Quantity:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="ReceivedQuantity" name="ReceivedQuantity" placeholder="Enter received quantity">
                                    </div>
                                </div>

                                <!-- WeightID Dropdown -->
                                <div class="form-group">
                                    <label for="WeightID" class="col-sm-4 control-label">Weight:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="WeightID" name="WeightID">
                                            <option>Select One</option>
                                            <!-- Options will be populated dynamically using JavaScript -->
                                        </select>
                                    </div>
                                </div>

                                <!-- ReceiveDate Input -->
                                <div class="form-group">
                                    <label for="ReceiveDate" class="col-sm-4 control-label">Receive Date:</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" id="ReceiveDate" name="ReceiveDate">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_receive"><i class="fa fa-save"></i> Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

   

    <script src="scripts.js"></script>
</body>
</html>
