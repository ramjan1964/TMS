<?php
// Connect to the database (replace placeholders with actual details)
$mysqli = new mysqli('localhost', 'root', '', 'tms');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Retrieve PurchaseOrderID from the request
$purchaseOrderId = $_GET['purchaseOrderId'];

// Fetch ProductName from the database based on the selected PurchaseOrderID
$query = "SELECT pm.ProductName 
          FROM purchaseordermanagement pom
          JOIN productmanagement pm ON pom.ProductID = pm.ProductID
          WHERE pom.PurchaseOrderID = '$purchaseOrderId'";

$result = $mysqli->query($query);

if ($result) {
    $row = $result->fetch_assoc();
    $productName = $row['ProductName'];

    echo $productName;
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
