document.addEventListener('DOMContentLoaded', function () {
    // Fetch PurchaseOrderID options from the server (you need to implement this)
    // and populate the dropdown list

    // Example:
    fetch('get_purchase_order_ids.php')
        .then(response => response.json())
        .then(data => {
            const purchaseOrderIdSelect = document.getElementById('purchaseOrderId');
            data.forEach(purchaseOrderId => {
                const option = document.createElement('option');
                option.value = purchaseOrderId;
                option.text = purchaseOrderId;
                purchaseOrderIdSelect.add(option);
            });
        });
});

function loadProductAndSupplierNames() {
    const purchaseOrderId = document.getElementById('purchaseOrderId').value;

    // Fetch ProductName and SupplierName based on the selected PurchaseOrderID from the server
    // and populate the ProductName and SupplierName fields

    // Example:
    fetch(`get_product_and_supplier_names.php?purchaseOrderId=${purchaseOrderId}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('productName').value = data.productName;
            document.getElementById('supplierName').value = data.supplierName;
        });
}

