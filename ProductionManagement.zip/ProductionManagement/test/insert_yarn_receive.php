<?php
// This file handles the insertion of yarn receive data into the database
// Retrieve data from the form
$purchaseOrderId = $_POST['purchaseOrderId'];
$productName = $_POST['productName'];
$receivedQuantity = $_POST['receivedQuantity'];
$receiveDate = $_POST['receiveDate'];

// Perform the database insertion (you need to implement this)
// Example using MySQLi:
$mysqli = new mysqli('localhost', 'root', '', 'tms');

if ($mysqli->connect_error) {
    die('Connection failed: ' . $mysqli->connect_error);
}

// Perform the insertion query here
$insertQuery = "INSERT INTO yarnreceivemanagement (PurchaseOrderID, ProductName, ReceivedQuantity, ReceiveDate) VALUES ('$purchaseOrderId', '$productName', '$receivedQuantity', '$receiveDate')";

if ($mysqli->query($insertQuery) === TRUE) {
    echo "Yarn receive data inserted successfully";
} else {
    echo "Error: " . $mysqli->error;
}

$mysqli->close();
?>
