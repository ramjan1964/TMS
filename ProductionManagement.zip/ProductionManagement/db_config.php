<?php
/*
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "TMS";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
*/
//above code is optional way to database connection with php file
$conn=mysqli_connect(hostname:'localhost',username:'root',password:'',database:'TMS');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
    ?>