<?php
require_once '../db_config.php';
require_once 'header.php';

$programNo = isset($_GET['program_no']) ? $_GET['program_no'] : '';
$success = $error = '';
$fabricNo = $fabricType = $fabricColor = $requiredQty = $unit = $price = $amount = $currency = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fabricNo = $_POST['fabric_no'];
    $fabricType = $_POST['fabric_type'];
    $fabricColor = $_POST['fabric_color'];
    $requiredQty = $_POST['required_qty'];
    $unit = $_POST['unit'];
    $price = $_POST['price'];
    $currency = $_POST['currency'];

    $amount = $price * $requiredQty;

    $swatchPath = '';
    if (!empty($_FILES['swatch_path']['name'])) {
        $uploadDir = '../images/swatches/';
        $swatchPath = $uploadDir . basename($_FILES['swatch_path']['name']);
        move_uploaded_file($_FILES['swatch_path']['tmp_name'], $swatchPath);
    }

    $insertSql = "INSERT INTO fabric_data (Program_no, fabric_no, fabric_type, fabric_color, required_qty, unit, price, amount, currency, swatch_path)
                  VALUES ('$programNo', '$fabricNo', '$fabricType', '$fabricColor', '$requiredQty', '$unit', '$price', '$amount', '$currency', '$swatchPath')";

    if ($conn->query($insertSql) === TRUE) {
        $success = 'Fabric data added successfully.';
    } else {
        $error = 'Error adding fabric data: ' . $conn->error;
    }
}

$fabricSql = "SELECT * FROM fabric_data where Program_no='$programNo'";
$fabricResult = $conn->query($fabricSql);
?>

<div class="content">
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Fabric Data</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-6 col-sm-offset-3">
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <h4 class="section-subtitle"><b>Fabric Data</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Fabric Data</h4>

                                <div class="form-group">
                                    <label for="Program_no" class="col-sm-4 control-label">Program No:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="Program_no" name='Program_no'
                                            placeholder="Type the Program No" value="<?= $programNo ?>" disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="fabric_no" class="col-sm-4 control-label">Fabric No:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="fabric_no" name='fabric_no'
                                            placeholder="Type the Fabric No"
                                            value="<?= isset($fabricNo) ? $fabricNo : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="fabric_type" class="col-sm-4 control-label">Fabric Type:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="fabric_type" name='fabric_type'
                                            placeholder="Type the Fabric Type"
                                            value="<?= isset($fabricType) ? $fabricType : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="fabric_color" class="col-sm-4 control-label">Fabric Color:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="fabric_color" name='fabric_color'
                                            placeholder="Type the Fabric Color"
                                            value="<?= isset($fabricColor) ? $fabricColor : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="required_qty" class="col-sm-4 control-label">Req. Qty:</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" id="required_qty" name='required_qty'
                                            placeholder="Type the required Fabric Qty"
                                            value="<?= isset($requiredQty) ? $requiredQty : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="unit" class="col-sm-4 control-label">Unit:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="unit" name="unit">
                                            <option value="usd" <?= isset($unit) && $unit === 'usd' ? 'selected' : '' ?>>KG
                                            </option>
                                            <option value="eur" <?= isset($unit) && $unit === 'eur' ? 'selected' : '' ?>>GM
                                            </option>
                                            <option value="gbp" <?= isset($unit) && $unit === 'gbp' ? 'selected' : '' ?>>
                                                M.Ton</option>
                                            <!-- Add more currency options as needed -->
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="price" class="col-sm-4 control-label">Price:</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" id="price" name='price'
                                            placeholder="Type the price" value="<?= isset($price) ? $price : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="currency" class="col-sm-4 control-label">Currency:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="currency" name="currency">
                                            <option value="taka" <?= isset($currency) && $currency === 'taka' ? 'selected' : '' ?>>TAKA</option>
                                            <option value="usd" <?= isset($currency) && $currency === 'usd' ? 'selected' : '' ?>>USD</option>
                                            <option value="eur" <?= isset($currency) && $currency === 'eur' ? 'selected' : '' ?>>EUR</option>
                                            <option value="gbp" <?= isset($currency) && $currency === 'gbp' ? 'selected' : '' ?>>GBP</option>
                                            <!-- Add more currency options as needed -->
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="swatch_path" class="col-sm-4 control-label">Swatch:</label>
                                    <div class="col-sm-8">
                                        <input type="file" class="form-control" id="swatch_path" name='swatch_path'>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_order"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="manage_program.php">Manage Program</a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="javascript:avoi(0)">Fabric Data</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">
            <div class="panel">
                <div class="panel-content">
                    <h5>Fabric Data</h5>
                    <div class="table-responsive">
                        <table
                            class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered"
                            cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Program No</th>
                                    <th>Fabric No</th>
                                    <!-- Add other table headers as needed -->
                                    <th>Fabric Type</th>
                                    <th>Fabric Color</th>
                                    <th>Req. Qty</th>
                                    <th>Unit</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Currency</th>
                                    <th>Swatch</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
    <?php
    if ($fabricResult->num_rows > 0) {
        while ($fabricRow = $fabricResult->fetch_assoc()) {
            ?>
            <tr>
            <td><?= $fabricRow['Program_no'] ?></td>
            <td><?= $fabricRow['fabric_no'] ?></td>
            <!-- Add other table data as needed -->
            <td><?= $fabricRow['fabric_type'] ?></td>
            <td><?= $fabricRow['fabric_color'] ?></td>
            <td><?= $fabricRow['required_qty'] ?></td>
            <td><?= $fabricRow['unit'] ?></td>
            <td><?= $fabricRow['price'] ?></td>
            <td><?= $fabricRow['amount'] ?></td>
            <td><?= $fabricRow['currency'] ?></td>
            <td><img src='<?= $fabricRow['swatch_path'] ?>' alt='Swatch' style='max-height: 40px;'></td>
            <td>
                <a href='#' class='btn btn-info' data-toggle='modal' data-target='#fabric_data-view-modal-<?= $fabricRow['id'] ?>'><i class='fa fa-eye'></i></a>
                <a href='#' class='btn btn-warning' data-toggle='modal' data-target='#fabric_data-update-modal-<?= $fabricRow['id'] ?>'><i class='fa fa-pencil'></i></a>
                <a href='yarn_info.php?fabric_no=<?= $fabricRow['fabric_no'] ?>' class='btn btn-primary'>Yarn</a>
                <a href='delete.php?orderdelete=<?= base64_encode($fabricRow['fabric_no']) ?>' class='btn btn-danger' onclick="return confirm('Are you sure to delete this fabric Program?')"><i class='fa fa-trash-o'></i></a>
            </td>
        </tr>
        <?php
        }
    } else {
        echo "<tr><td colspan='10'>No fabric data found</td></tr>";
    }
    ?>
</tbody>


                        </table>
                    </div>
                </div>
            </div>
            </div>
</div>

<!-- Fabric Data View Modal -->
<?php
$fabricResult = $conn->query($fabricSql); // Resetting the result set
if ($fabricResult->num_rows > 0) {
    while ($fabricRow = $fabricResult->fetch_assoc()) {
        ?>
      <!-- Fabric Data View Modal -->
<div class="modal fade" id="fabric_data-view-modal-<?= $fabricRow['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="fabricDataViewModal" aria-hidden="true">
    <div class="modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fabricDataViewModal">Fabric Data Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            <div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Program No</th>
                <th>Fabric No</th>
                <th>Fabric Type</th>
                <th>Fabric Color</th>
                <th>Req. Qty</th>
                <th>Unit</th>
                <th>Price</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Swatch</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($fabricResult->num_rows > 0) {
                while ($fabricRow = $fabricResult->fetch_assoc()) {
                    echo "<tr>
                            <td>{$fabricRow['Program_no']}</td>
                            <td>{$fabricRow['fabric_no']}</td>
                            <td>{$fabricRow['fabric_type']}</td>
                            <td>{$fabricRow['fabric_color']}</td>
                            <td>{$fabricRow['required_qty']}</td>
                            <td>{$fabricRow['unit']}</td>
                            <td>{$fabricRow['price']}</td>
                            <td>{$fabricRow['amount']}</td>
                            <td>{$fabricRow['currency']}</td>
                            <td><img src='{$fabricRow['swatch_path']}' alt='Swatch' style='max-height: 40px;'></td>
                         
                        </tr>";
                }
            } else {
                echo "<tr><td colspan='11'>No fabric data found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

                <!-- Add more details as needed -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
        <?php
    }
}
?>

<?php
$fabricResult = $conn->query($fabricSql); // Resetting the result set
if ($fabricResult->num_rows > 0) {
    while ($fabricRow = $fabricResult->fetch_assoc()) {
        ?>
<!-- Fabric Data Update Modal -->
<div class="modal fade" id="fabric_data-update-modal-<?= $fabricRow['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="fabricDataUpdateModal" aria-hidden="true">
<div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="fabricDataUpdateModal">Update Fabric Data</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="fabric_id" value="<?= $fabricRow['id'] ?>">

                    <div class="form-group">
                        <label for="update_fabric_no">Fabric No:</label>
                        <input type="text" id="update_fabric_no" name="update_fabric_no" value="<?= $fabricRow['fabric_no'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="update_fabric_type">Fabric Type:</label>
                        <input type="text" id="update_fabric_type" name="update_fabric_type" value="<?= $fabricRow['fabric_type'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="update_fabric_color">Fabric Color:</label>
                        <input type="text" id="update_fabric_color" name="update_fabric_color" value="<?= $fabricRow['fabric_color'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="update_required_qty">Required Qty:</label>
                        <input type="number" id="update_required_qty" name="update_required_qty" value="<?= $fabricRow['required_qty'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="update_unit">Unit:</label>
                        <select id="update_unit" name="update_unit" class="form-control">
                            <option value="usd" <?= $fabricRow['unit'] === 'usd' ? 'selected' : '' ?>>KG</option>
                            <option value="eur" <?= $fabricRow['unit'] === 'eur' ? 'selected' : '' ?>>GM</option>
                            <option value="gbp" <?= $fabricRow['unit'] === 'gbp' ? 'selected' : '' ?>>M.Ton</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="update_price">Price:</label>
                        <input type="number" id="update_price" name="update_price" value="<?= $fabricRow['price'] ?>" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="update_currency">Currency:</label>
                        <select id="update_currency" name="update_currency" class="form-control">
                            <option value="taka" <?= $fabricRow['currency'] === 'taka' ? 'selected' : '' ?>>TAKA</option>
                            <option value="usd" <?= $fabricRow['currency'] === 'usd' ? 'selected' : '' ?>>USD</option>
                            <option value="eur" <?= $fabricRow['currency'] === 'eur' ? 'selected' : '' ?>>EUR</option>
                            <option value="gbp" <?= $fabricRow['currency'] === 'gbp' ? 'selected' : '' ?>>GBP</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="update_swatch_path">Swatch:</label>
                        <input type="file" id="update_swatch_path" name="update_swatch_path" class="form-control">
                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary"data-dismiss="modal">Update Fabric Data</button>

            </div>
        </div>
    </div>
    <?php
    }
}
?>
</div>
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
<?php require_once 'footer.php'; ?>