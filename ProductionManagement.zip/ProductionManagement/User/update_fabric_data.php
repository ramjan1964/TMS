<?php
require_once '../db_config.php';

$fabricDataId = isset($_POST['fabric_id']) ? $_POST['fabric_id'] : '';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate other form fields as needed
    $updateFabricNo = $_POST['update_fabric_no'];
    $updateFabricType = $_POST['update_fabric_type'];
    $updateFabricColor = $_POST['update_fabric_color'];
    $updateRequiredQty = $_POST['update_required_qty'];
    $updateUnit = $_POST['update_unit'];
    $updatePrice = $_POST['update_price'];
    $updateCurrency = $_POST['update_currency'];
    
    // Initialize variable
    $updateSwatch = '';

    // Handle file upload if a new swatch is provided
    if (!empty($_FILES['update_swatch_path']['name'])) {
        $uploadDir = '../images/swatches/';
        $updateSwatch = $uploadDir . basename($_FILES['update_swatch_path']['name']);
        move_uploaded_file($_FILES['update_swatch_path']['tmp_name'], $updateSwatch);
    }

    // Update fabric program data in the database
    $updateSql = "UPDATE fabric_data SET 
                  fabric_no = '$updateFabricNo',
                  fabric_type = '$updateFabricType',
                  fabric_color = '$updateFabricColor',
                  required_qty = '$updateRequiredQty',
                  unit = '$updateUnit',
                  price = '$updatePrice',
                  currency = '$updateCurrency',
                  swatch_path = '$updateSwatch'
                  WHERE id = '$fabricDataId'";

    if ($conn->query($updateSql) === TRUE) {
        // Successfully updated
        header("Location: fabric_data.php"); // Update to the appropriate page
        exit();
    } else {
        // Error in updating
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Redirect if accessed directly
    header("Location: fabric_data.php"); // Update to the appropriate page
    exit();
}

// Close the database connection
$conn->close();
?>

