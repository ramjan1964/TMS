<?php
require_once '../db_config.php';
if(isset($_GET['orderdelete'])){
    $id=base64_decode($_GET['orderdelete']);   
    mysqli_query($conn, "DELETE FROM knitting_order WHERE id='$id'") or die(mysqli_error($conn));
    header('location:manage_knitting_order.php');
}
?>