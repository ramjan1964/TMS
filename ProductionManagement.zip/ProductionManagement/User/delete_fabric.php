<?php
require_once '../db_config.php';
if(isset($_GET['fabricDelete'])){
    $id=base64_decode($_GET['fabricDelete']);   
    mysqli_query($conn, "DELETE FROM fabric_data WHERE id='$id'") or die(mysqli_error($conn));
    header('location:fabric_data.php');
}
?>