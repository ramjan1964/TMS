<?php
require_once '../db_config.php';
$yarnDataId = isset($_POST['yarn_id']) ? $_POST['yarn_id'] : '';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
   
    $editYarnName = isset($_POST['edit_yarn_name']) ? $_POST['edit_yarn_name'] : '';
    $editYarnType = isset($_POST['edit_yarn_type']) ? $_POST['edit_yarn_type'] : '';
    $editYarnColor = isset($_POST['edit_yarn_color']) ? $_POST['edit_yarn_color'] : '';
    $editYarnQty = isset($_POST['edit_yarn_qty']) ? $_POST['edit_yarn_qty'] : '';

// Update yarn data in the database
$updateSql = "UPDATE yarn_info SET yarn_name='$editYarnName', yarn_type='$editYarnType', 
              yarn_color='$editYarnColor', yarn_qty='$editYarnQty' WHERE id='$yarnDataId'";

if ($conn->query($updateSql) === TRUE) {
    // Successfully updated
    header("Location: yarn_info.php?fabric_no=$fabricNo&success=Yarn data updated successfully.");
    exit();
} else {
    // Error in update
    header("Location: yarn_info.php?fabric_no=$fabricNo&error=Error updating yarn data: " . $conn->error);
    exit();
}
} else {
    // Invalid request method
    header("Location: yarn_info.php?fabric_no=$fabricNo&error=Invalid request method.");
    exit();
}
?>
