<?php
require_once '../db_config.php';




require_once 'header.php';
?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">userlist</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">
        
                <!-- Knitting Order List -->
            <div class="panel">
            
                <div class="panel-content">
                    <h5>Knitting Order List</h5>
                    <div class="table-responsive">
                    <table id="basic-table" class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered" cellspacing="0" width="100%">
                        <thead>
                        <tr>
                            <th>Buyer</th>
                            <th>Style</th>
                            <th>Program No</th>
                            <th>Fabric No</th>
                            <th>Fabric Type</th>
                            <th>Fabric Color</th>
                            <th>Req. Qty</th>
                            <th>Unit</th>
                            <th>Swatch Path</th>
                            <th>Program Date</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        /*
if ($orderResult->num_rows > 0) {
    while ($orderRow = $orderResult->fetch_assoc()) {
        echo "<tr>
                <td>{$orderRow['buyer']}</td>
                <td>{$orderRow['style']}</td>
                <td>{$orderRow['Program_no']}</td>
                <td>{$orderRow['fabric_no']}</td>
                <td>{$orderRow['fabric_type']}</td>
                <td>{$orderRow['fabric_color']}</td>
                <td>{$orderRow['required_qty']}</td>
                <td>{$orderRow['unit']}</td>
                <td>{$orderRow['price']}</td>
                <td>{$orderRow['amount']}</td>
                <td>{$orderRow['currency']}</td>
                <td><img src='../images/knitting/{$orderRow['swatch_path']}' alt='Swatch' style='max-height: 40px;'></td>
                <td>" . date('d-M-Y', strtotime($orderRow['order_date'])) . "</td>
                <td>
                <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal' data-target='#knitting-order<?={$orderRow['id']}?>'><i class='fa fa-eye'></i></a>
                <a href='#' class='btn btn-primary'><i class='fa fa-plus'></i></a>
                <a href='#' class='btn btn-warning'><i class='fa fa-pencil'></i></a>
                <a href='#' class='btn btn-danger'><i class='fa fa-trash-o'></i></a>

            </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='14'>No knitting orders found</td></tr>";
}
*/
?>
<!--optional way of data diplay-->
<?php
// Fetch knitting order data
$orderSql = "SELECT * FROM knitting_order";
$orderResult = $conn->query($orderSql);
if ($orderResult->num_rows > 0): ?>
    <?php while ($orderRow = $orderResult->fetch_assoc()): ?>
        <tr>
            <td><?= $orderRow['buyer'] ?></td>
            <td><?= $orderRow['style'] ?></td>
            <td><?= $orderRow['Program_no'] ?></td>
            <td><?= $orderRow['fabric_no'] ?></td>
            <td><?= $orderRow['fabric_type'] ?></td>
            <td><?= $orderRow['fabric_color'] ?></td>
            <td><?= $orderRow['required_qty'] ?></td>
           
            <td><img src="../images/knitting/<?= $orderRow['swatch_path'] ?>" alt="Swatch" style="max-height: 40px;"></td>
            <td><?= date('d-M-Y', strtotime($orderRow['order_date'])) ?></td>
            <td>
                <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal' data-target='#knitting_order-<?=$orderRow['id']?>'><i class='fa fa-eye'></i></a>
                <a href='#' class='btn btn-warning'><i class='fa fa-pencil'></i></a>
                <a href='#' class='btn btn-primary'>yarn</i></i></a>
                <a href="delete.php?orderdelete=<?= base64_encode($orderRow['id']) ?>" class='btn btn-danger' onclick="return confirm('Are you sure to delete this order?')"><i class='fa fa-trash-o'></i></a>

            </td>
        </tr>
    <?php endwhile; ?>
<?php else: ?>
    <tr><td colspan="14">No knitting orders found</td></tr>
<?php endif; 

?>


                        </tbody>
                    </table>
                </div>
            </div>
            <!-- End Knitting Order List -->
        </div>
    </div>

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>
<?php
// Fetch knitting order data
$orderSql = "SELECT * FROM knitting_order";
$orderResult = $conn->query($orderSql);
if ($orderResult->num_rows > 0): ?>
    <?php while ($orderRow = $orderResult->fetch_assoc()): ?>
    ?>
<!-- Modal -->
<div class="modal fade" id="knitting_order-<?=$orderRow['id']?>" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
                                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header state modal-info">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i>Knitting Order Information:</h4>
                                        </div>
                                        <table class="table table-bordered">
                        <!-- Your table headers go here -->
                        <tr>
                            <th>Buyer</th>
                            <th>Style</th>
                            <th>Program No</th>
                            <th>Fabric No</th>
                            <th>Fabric Type</th>
                            <th>Fabric Color</th>
                            <th>Req. Qty</th>
                            <th>Unit</th>
                            
                            <th>Swatch Path</th>
                            <th>Order Date</th>
                           
                        </tr>
                        <!-- Your table data goes here -->
                        <tr>
                            <td><?= $orderRow['buyer'] ?></td>
                            <td><?= $orderRow['style'] ?></td>
                            <td><?= $orderRow['Program_no'] ?></td>
                            <td><?= $orderRow['fabric_no'] ?></td>
                            <td><?= $orderRow['fabric_type'] ?></td>
                            <td><?= $orderRow['fabric_color'] ?></td>
                            <td><?= $orderRow['required_qty'] ?></td>
                            <td><?= $orderRow['unit'] ?></td>
                         
                            <td><img src="../images/knitting/<?= $orderRow['swatch_path'] ?>" alt="Swatch" style="max-height: 40px;"></td>
                            <td><?= date('d-M-Y', strtotime($orderRow['order_date'])) ?></td>
                           
                        </tr>
                    </table>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-info" data-dismiss="modal">Ok</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
<?php else: ?>

<?php endif; 

?>

<?php
require_once 'footer.php';
?>
