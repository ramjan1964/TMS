<?php
// Include your database configuration file
require_once '../db_config.php';

// Start the session
session_start();

// Check if the user is already logged in, then redirect to the dashboard
if (isset($_SESSION['userlogin1'])) {
    header('location: index.php');
    exit;
}

// Check if the forget password form is submitted
if (isset($_POST['forget_password'])) {
    // Get the email from the form
    $email = $_POST['email'];

    // Query the database to check if the email exists
    $result = mysqli_query($conn, "SELECT * FROM `user` WHERE `email` = '$email'");

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);

        // Generate a unique token for the password reset link
        $token = bin2hex(random_bytes(32));

        // Save the token and its expiration time in the database
        $token_expiration = date('Y-m-d H:i:s', strtotime('+1 hour'));
        mysqli_query($conn, "UPDATE `user` SET `reset_token` = '$token', `token_expiration` = '$token_expiration' WHERE `email` = '$email'");

        // Send a password reset email to the user
        $reset_link = "http://yourwebsite.com/reset_password.php?email=$email&token=$token";
        $subject = "Password Reset Request";
        $message = "Click the following link to reset your password: $reset_link";
        mail($email, $subject, $message);

        $success_message = "Password reset link has been sent to your email. Please check your inbox.";
    } else {
        $common_error = "Email not found. Please check your email and try again.";
    }
}

// Check if the reset password form is submitted
if (isset($_POST['reset_password'])) {
    // Get the email, token, and new password from the form
    $email = $_POST['email'];
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];

    // Check if the token is valid and not expired
    $result = mysqli_query($conn, "SELECT * FROM `user` WHERE `email` = '$email' AND `reset_token` = '$token' AND `token_expiration` > NOW()");

    if (mysqli_num_rows($result) > 0) {
        // Reset the password and clear the token fields
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        mysqli_query($conn, "UPDATE `user` SET `password` = '$hashed_password', `reset_token` = NULL, `token_expiration` = NULL WHERE `email` = '$email'");

        $success_message = "Password reset successful. You can now log in with your new password.";
    } else {
        $common_error = "Invalid or expired token. Please try again.";
    }
}
?>
<!doctype html>
<html lang="en" class="fixed accounts sign-in">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>PMS</title>
    <!-- BASIC css -->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="../vendor/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="../vendor/animate.css/animate.css">
    <!-- SECTION css -->
    <!-- ========================================================= -->
    <!-- TEMPLATE css -->
    <!-- ========================================================= -->
    <link rel="stylesheet" href="../stylesheets/css/style.css">
</head>
<body>
    <div class="wrap">
        <!-- page BODY -->
        <!-- ========================================================= -->
        <div class="page-body animated slideInDown">
            <!-- LOGO -->
            <div class="logo">
                <h1 class="text-center">PMS</h1>
                <?php
                // Display success message
                if (isset($success_message)) {
                    ?>
                    <div class="alert alert-success" role="alert">
                        <?= $success_message ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php
                }

                // Display common error message
                if (isset($common_error)) {
                    ?>
                    <div class="alert alert-danger" role="alert">
                        <?= $common_error ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php
                } 
                ?>
            </div>
            <div class="box">
                <!-- FORGET PASSWORD FORM -->
                <div class="panel mb-none">
                    <div class="panel-content bg-scale-0">
                        <form method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
                            <div class="form-group mt-md">
                                <span class="input-with-icon">
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Your Email" value="<?= isset($email) ? $email : '' ?>">
                                    <i class="fa fa-envelope"></i>
                                </span>
                            </div>
                            <div class="form-group">
                                <div class="checkbox-custom checkbox-primary">
                                    <input type="checkbox" id="remember-me" value="option1" checked>
                                    <label class="check" for="remember-me">Remember me</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-block" name="forget_password" value="Forget Password">
                            </div>
                        </form>
                    </div>
                </div>

                <!-- RESET PASSWORD FORM -->
                <div class="panel mb-none">
                    <div class="panel-content bg-scale-0">
                        <form method="post" action="<?= $_SERVER['PHP_SELF'] ?>">
                            <div class="form-group mt-md">
                                <span class="input-with-icon">
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Your Email" value="<?= isset($email) ? $email : '' ?>" readonly>
                                    <i class="fa fa-envelope"></i>
                                </span>
                            </div>
                            <div class="form-group mt-md">
                                <span class="input-with-icon">
                                    <input type="text" class="form-control" id="token" name="token" placeholder="Reset Token" value="<?= isset($token) ? $token : '' ?>">
                                    <i class="fa fa-key"></i>
                                </span>
                            </div>
                            <div class="form-group">
                                <span class="input-with-icon">
                                    <input type="password" class="form-control" id="new_password" name="new_password" placeholder="New Password">
                                    <i class="fa fa-key"></i>
                                </span>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-primary btn-block" name="reset_password" value="Reset Password">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
    </div>
    <!-- BASIC scripts -->
    <!-- ========================================================= -->
    <script src="../vendor/jquery/jquery-1.12.3.min.js"></script>
    <script src="../vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="../vendor/nano-scroller/nano-scroller.js"></script>
    <!-- TEMPLATE scripts -->
    <!-- ========================================================= -->
    <script src="../javascripts/template-script.min.js"></script>
    <script src="../javascripts/template-init.min.js"></script>
    <!-- SECTION script and examples -->
    <!-- ========================================================= -->
</body>
</html>
