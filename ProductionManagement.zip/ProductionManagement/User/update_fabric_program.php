<?php
require_once '../db_config.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve fabric program ID
    $fabricProgramId = isset($_POST['fabric_program_id']) ? $_POST['fabric_program_id'] : '';

    // Validate other form fields as needed
    $buyer = $_POST['edit_buyer'];
    $style = $_POST['edit_style'];
    $programNo = $_POST['edit_program_no'];
    $requiredQty = $_POST['edit_required_qty'];
    $unit = $_POST['edit_unit'];
    $programDate = $_POST['edit_program_date'];

    // Update fabric program data in the database
    $updateSql = "UPDATE fabric_program SET 
                  buyer = '$buyer',
                  style = '$style',
                  Program_no = '$programNo',
                  required_qty = '$requiredQty',
                  unit = '$unit',
                  programDate = '$programDate'
                  WHERE id = '$fabricProgramId'";

    if ($conn->query($updateSql) === TRUE) {
        // Successfully updated
        header("Location: manage_program.php"); // Update to the appropriate page
        exit();
    } else {
        // Error in updating
        echo "Error updating record: " . $conn->error;
    }
} else {
    // Redirect if accessed directly
    header("Location: manage_program.php"); // Update to the appropriate page
    exit();
}

// Close the database connection
$conn->close();
?>
