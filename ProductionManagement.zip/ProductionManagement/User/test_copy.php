<?php
require_once '../db_config.php';
require_once 'header.php';

// Check if the yarn form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['yarn_submit'])) {
    // Retrieve yarn information from the form
    $fabricNo = $_POST['fabric_no'];
    $yarn_name = $_POST['yarn_name'];
    $yarnType = $_POST['yarn_type'];
    $yarnColor = $_POST['yarn_color'];
    $yarnQty = $_POST['yarn_qty'];

    // TODO: Perform validation if needed

    // Insert yarn information into the database
    $insertSql = "INSERT INTO yarn_info (fabric_no, yarn_name, yarn_type, yarn_color, yarn_qty) VALUES ('$fabricNo', '$yarn_name', '$yarnType', '$yarnColor', $yarnQty)";
    if ($conn->query($insertSql) === TRUE) {
        // Yarn information successfully inserted
        $successMessage = "Yarn information saved successfully!";
    } else {
        // Error inserting yarn information
        $errorMessage = "Error: " . $insertSql . "<br>" . $conn->error;
    }
}

// Fetch knitting order data
$result = mysqli_query($conn, "SELECT * FROM `knitting_order`");
?>

<!-- CONTENT -->
<div class="content">
    <div class="content-header">
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">userlist</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">
            <!-- Knitting Order List -->
            <div class="panel">
                <div class="panel-content">
                    <h5>Knitting Order List</h5>
                    <div class="table-responsive">
                        <table id="basic-table" class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>Buyer</th>
                                    <th>Style</th>
                                    <th>Program No</th>
                                    <th>Fabric No</th>
                                    <!-- Add a new column for the yarn icons -->
                                    <th>Yarn Info</th>
                                    <th>Fabric Type</th>
                                    <th>Fabric Color</th>
                                    <th>Req. Qty</th>
                                    <th>Unit</th>
                                    <th>Price</th>
                                    <th>Amount</th>
                                    <th>Currency</th>
                                    <th>Swatch Path</th>
                                    <th>Order Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($orderRow = mysqli_fetch_array($result)) : ?>
                                    <tr>
                                        <td><?= $orderRow['buyer'] ?></td>
                                        <td><?= $orderRow['style'] ?></td>
                                        <td><?= $orderRow['Program_no'] ?></td>
                                        <td><?= $orderRow['fabric_no'] ?></td>
                                        <!-- Add a plus icon for yarn info -->
                                        <td>
                                            <a href='#' class='btn btn-primary' data-toggle='modal' data-target='#yarnModal' data-fabric-no='<?= $orderRow['fabric_no'] ?>' data-yarn-name='<?= $orderRow['yarn_name'] ?>'>
                                                <i class='fa fa-plus'></i>
                                            </a>
                                            <a href='#' class='btn btn-info' data-toggle='modal' data-target='#displayYarnModal' data-fabric-no='<?= $orderRow['fabric_no'] ?>' data-yarn-name='<?= $orderRow['yarn_name'] ?>'>
                                                <i class='fa fa-eye'></i>
                                            </a>
                                        </td>
                                        <td><?= $orderRow['fabric_type'] ?></td>
                                        <td><?= $orderRow['fabric_color'] ?></td>
                                        <td><?= $orderRow['required_qty'] ?></td>
                                        <td><?= $orderRow['unit'] ?></td>
                                        <td><?= $orderRow['price'] ?></td>
                                        <td><?= $orderRow['amount'] ?></td>
                                        <td><?= $orderRow['currency'] ?></td>
                                        <td><img src="../images/knitting/<?= $orderRow['swatch_path'] ?>" alt="Swatch" style="max-height: 40px;"></td>
                                        <td><?= date('d-M-Y', strtotime($orderRow['order_date'])) ?></td>
                                        <td>
                                            <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal' data-target="#knitting_order-<?= $orderRow['id'] ?>"><i class='fa fa-eye'></i></a>
                                            <a href='#' class='btn btn-warning'><i class='fa fa-pencil'></i></a>
                                            <a href='#' class='btn btn-danger'><i class='fa fa-trash-o'></i></a>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- End Knitting Order List -->
        </div>
    </div>

    <!-- Yarn Modal -->
    <div class="modal fade" id="yarnModal" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
        <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header state modal-info">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i> Yarn Information:</h4>
                </div>
                <div class="modal-body">
                    <!-- Yarn Information Form -->
                    <form method="POST" action="">
                        <!-- Add hidden inputs to store fabric_no and yarn_name -->
                        <input type="hidden" name="fabric_no" id="yarnFabricNo" value="">
                        <input type="hidden" name="yarn_name" id="yarnYarnName" value="">
                        <div class="form-group">
                            <label for="yarn_name">Yarn name:</label>
                            <input type="text" class="form-control" name="yarn_name" required>
                        </div>
                        <div class="form-group">
                            <label for="yarn_type">Yarn Type:</label>
                            <input type="text" class="form-control" name="yarn_type" required>
                        </div>
                        <div class="form-group">
                            <label for="yarn_color">Yarn Color:</label>
                            <input type="text" class="form-control" name="yarn_color" required>
                        </div>
                        <div class="form-group">
                            <label for="yarn_qty">Yarn Quantity:</label>
                            <input type="number" class="form-control" name="yarn_qty" required>
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-info" name="yarn_submit">Save</button>
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

   <!-- Display Yarn Modal -->
<div class="modal fade" id="displayYarnModal" tabindex="-1" role="dialog" aria-labelledby="modal-info-label">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header state modal-info">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i> Display Yarn Information:</h4>
            </div>
            <div class="modal-body">
                <?php
                // Check if fabric_no and yarn_name are set
                if (isset($_GET['fabric_no'])) {
                    // Retrieve fabric_no and yarn_name from the URL
                    $fabricNo = $_GET['fabric_no'];
                   
                    // Fetch yarn information based on fabric_no and yarn_name
                    $yarnResult = mysqli_query($conn, "SELECT * FROM `yarn_info` WHERE `fabric_no` = '$fabricNo'");

                    // Check if yarn information is available
                    if ($yarnResult && mysqli_num_rows($yarnResult) > 0) {
                        $yarnData = mysqli_fetch_assoc($yarnResult);
                        ?>
                        <h5>Yarn Information</h5>
                        <table class="table table-bordered">
                            <tr>
                                <th>Yarn Name</th>
                                <td><?= $yarnData['yarn_name'] ?></td>
                            </tr>
                            <tr>
                                <th>Yarn Type</th>
                                <td><?= $yarnData['yarn_type'] ?></td>
                            </tr>
                            <tr>
                                <th>Yarn Color</th>
                                <td><?= $yarnData['yarn_color'] ?></td>
                            </tr>
                            <tr>
                                <th>Yarn Quantity</th>
                                <td><?= $yarnData['yarn_qty'] ?></td>
                            </tr>
                        </table>
                        <?php
                    } else {
                        echo '<p>No yarn information available.</p>';
                    }
                } else {
                    echo '<p>Invalid request. Please provide fabric_no and yarn_name.</p>';
                }
                ?>
            </div>
        </div>
    </div>
</div>


    <!-- Your existing modals go here -->

    <!--scroll to top-->
    <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
</div>
</div>

<?php
require_once 'footer.php';
?>
