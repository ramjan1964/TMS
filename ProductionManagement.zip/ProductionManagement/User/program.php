        <?php

require_once 'header.php';
        ?>
        
        
        <!-- CONTENT -->
        <!-- ========================================================= -->
        <div class="content">
    <!-- content HEADER -->
<!-- ========================================================= -->
<div class="content-header">
    <!-- leftside content header -->
    <div class="leftside-content-header">
        <ul class="breadcrumbs">
            <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
            <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add knitting Order</a></li>
        </ul>
    </div>
</div>
            <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->
            <div class="row animated fadeInUp">
                <!--SETTINGS-->
                <div class="col-sm-6 col-sm-offset-3">
                    <h4 class="section-subtitle"><b>Knit Dyeing Program</b></h4>
                    <div class="panel">
                        <div class="panel-content">
                            <div class="row">
                                <div class="col-md-12">
                                    <form class="form-horizontal">
                                        <h4 class="mb-lg">Add knitting Dyeing Program</h4>
        
                                        <div class="form-group">
                                            <label for="buyer" class="col-sm-4 control-label">Buyer:</label>
                                            <div class="col-sm-8">
                                                <input type="buyer" class="form-control" id="buyer"
                                                    placeholder="Type the buyer Name">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="style" class="col-sm-4 control-label">Style:</label>
                                            <div class="col-sm-8">
                                                <input type="style" class="form-control" id="style"
                                                    placeholder="Type the style No">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="Program_no" class="col-sm-4 control-label">Program No:</label>
                                            <div class="col-sm-8">
                                                <input type="Program_no" class="form-control" id="Program_no"
                                                    placeholder="Type the Program No">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="fabric_no" class="col-sm-4 control-label">Fabric No:</label>
                                            <div class="col-sm-8">
                                                <input type="fabric_no" class="form-control" id="fabric_no"
                                                    placeholder="Type the Fabric No">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="fabric_type" class="col-sm-4 control-label">Fabric Type:</label>
                                            <div class="col-sm-8">
                                                <input type="fabric_type" class="form-control" id="fabric_type"
                                                    placeholder="Type the Fabric Type">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="fabric_color" class="col-sm-4 control-label">Fabric Color:</label>
                                            <div class="col-sm-8">
                                                <input type="fabric_color" class="form-control" id="fabric_color"
                                                    placeholder="Type the Fabric Color">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="required_qty" class="col-sm-4 control-label">Required Qty:</label>
                                            <div class="col-sm-8">
                                                <input type="required_qty" class="form-control" id="required_qty"
                                                    placeholder="Type the required Fabric Qty">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="price" class="col-sm-4 control-label">Price:</label>
                                            <div class="col-sm-8">
                                                <input type="price" class="form-control" id="price"
                                                    placeholder="Type the price">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="amount" class="col-sm-4 control-label">Amount:</label>
                                            <div class="col-sm-8">
                                                <input type="amount" class="form-control" id="amount"
                                                    placeholder="Type the amount">
                                            </div>
                                        </div>
        
                                        <div class="form-group">
                                            <div class="col-sm-offset-2 col-sm-10">
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </div>
                                        </div>
        
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

               

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>

<?php
require_once 'footer.php';
?>