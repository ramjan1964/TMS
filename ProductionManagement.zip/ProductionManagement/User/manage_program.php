<?php
require_once '../db_config.php';


require_once 'header.php';
?>


<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Fabric Program</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">

            <!-- Fabric Program List -->
            <div class="panel">

                <div class="panel-content">
                    <h5>Knitting Order List</h5>
                    <div class="table-responsive">
                        <table id="basic-table"
                            class="data-table table table-striped nowrap table-hover dataTable no-footer table-bordered"
                            cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th style="text-align: center;">Buyer</th>
                                    <th style="text-align: center;">Style</th>
                                    <th style="text-align: center;">Program No</th>
                                    <th style="text-align: center;">Req. Qty</th>
                                    <th style="text-align: center;">Unit</th>
                                    <th style="text-align: center;">Order Date</th>
                                    <th style="text-align: center;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                /*
        if ($orderResult->num_rows > 0) {
            while ($orderRow = $orderResult->fetch_assoc()) {
                echo "<tr>
                        <td>{$orderRow['buyer']}</td>
                        <td>{$orderRow['style']}</td>
                        <td>{$orderRow['Program_no']}</td>
                        <td>{$orderRow['fabric_no']}</td>
                        <td>{$orderRow['fabric_type']}</td>
                        <td>{$orderRow['fabric_color']}</td>
                        <td>{$orderRow['required_qty']}</td>
                        <td>{$orderRow['unit']}</td>
                        <td>{$orderRow['price']}</td>
                        <td>{$orderRow['amount']}</td>
                        <td>{$orderRow['currency']}</td>
                        <td><img src='../images/knitting/{$orderRow['swatch_path']}' alt='Swatch' style='max-height: 40px;'></td>
                        <td>" . date('d-M-Y', strtotime($orderRow['order_date'])) . "</td>
                        <td>
                        <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal' data-target='#knitting-order<?={$orderRow['id']}?>'><i class='fa fa-eye'></i></a>
                        <a href='#' class='btn btn-primary'><i class='fa fa-plus'></i></a>
                        <a href='#' class='btn btn-warning'><i class='fa fa-pencil'></i></a>
                        <a href='#' class='btn btn-danger'><i class='fa fa-trash-o'></i></a>

                    </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='14'>No knitting orders found</td></tr>";
        }
        */
                                ?>
                                <!--optional way of data diplay-->
                                <?php
                                // Fetch Fabric Program data
                                $orderSql = "SELECT * FROM fabric_program";
                                $orderResult = $conn->query($orderSql);
                                if ($orderResult->num_rows > 0): ?>
                                    <?php while ($orderRow = $orderResult->fetch_assoc()): ?>
                                        <tr>
                                            <td>
                                                <?= $orderRow['buyer'] ?>
                                            </td>
                                            <td>
                                                <?= $orderRow['style'] ?>
                                            </td>
                                            <td>
                                                <?= $orderRow['program_no'] ?>
                                            </td>
                                            <td>
                                                <?= $orderRow['required_qty'] ?>
                                            </td>
                                            <td>
                                                <?= $orderRow['unit'] ?>
                                            </td>
                                            <td>
                                                <?= date('d-M-Y', strtotime($orderRow['programDate'])) ?>
                                            </td>

                                            <td>
                                                <a href='javascript:avoid(0)' class='btn btn-info' data-toggle='modal'
                                                    data-target='#knitting_order-<?= $orderRow['id'] ?>'><i
                                                        class='fa fa-eye'></i></a>
                                                <a href='javascript:avoid(0)' class='btn btn-warning' data-toggle='modal'
                                                    data-target='#fabric_program_update-<?= $orderRow['id'] ?>'><i
                                                        class='fa fa-pencil'></i></a>
                                                <a href="fabric_data.php?program_no=<?= $orderRow['program_no'] ?>"
                                                    class="btn btn-primary">Fabric</a>
                                                <a href="delete.php?orderdelete=<?= base64_encode($orderRow['id']) ?>"
                                                    class='btn btn-danger'
                                                    onclick="return confirm('Are you sure to delete this fabric Program?')"><i
                                                        class='fa fa-trash-o'></i></a>
                                            </td>

                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="14">No Fabric Program found</td>
                                    </tr>
                                <?php endif;

                                ?>


                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- End Fabric Program Order List -->
            </div>
        </div>

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>
<?php
// Fetch Fabric Program Data
$orderSql = "SELECT * FROM fabric_program";
$orderResult = $conn->query($orderSql);
if ($orderResult->num_rows > 0): ?>
    <?php while ($orderRow = $orderResult->fetch_assoc()): ?>
        ?>
        <!-- Modal -->
   
            <div class="modal fade" id="knitting_order-<?= $orderRow['id'] ?>" tabindex="-1" role="dialog"
                aria-labelledby="fabricDataViewModal" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                    <div class="modal-header state modal-info">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i>Fabric Program Information:</h4>
                    </div>
                    <table class="table table-bordered">
                        <!-- Your table headers go here -->
                        <tr>
                            <th>Buyer</th>
                            <th>Style</th>
                            <th>Program No</th>
                            <th>Req. Qty</th>
                            <th>Unit</th>
                            <th>Program Date</th>

                        </tr>
                        <!-- Your table data goes here -->
                       <tr>
                            <td>
                                <?= $orderRow['buyer'] ?>
                            </td>
                            <td>
                                <?= $orderRow['style'] ?>
                            </td>
                            <td>
                                <?= $orderRow['program_no'] ?>
                            </td>
                            <td>
                                <?= $orderRow['required_qty'] ?>
                            </td>
                            <td>
                                <?= $orderRow['unit'] ?>
                            </td>
                            <td>
                                <?= date('d-M-Y', strtotime($orderRow['programDate'])) ?>
                            </td>

                        </tr>
                    </table>
                    <div class="modal-footer">

                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>

<?php endif;

?>
<?php
// Fetch Fabric Program Data
$orderSql = "SELECT * FROM fabric_program";
$orderResult = $conn->query($orderSql);
if ($orderResult->num_rows > 0): ?>
    <?php while ($orderRow = $orderResult->fetch_assoc()): ?>
        ?>
        <!-- Modal -->
        <div class="modal fade" id="fabric_program_update-<?= $orderRow['id'] ?>" tabindex="-1" role="dialog"
            aria-labelledby="modal-update-label">
            <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header state modal-warning">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="modal-update-label"><i class="fa fa-pencil"></i>Edit Fabric Program:</h4>
                    </div>
                    <div class="modal-body">
                        <!-- Form for editing fabric program data -->
                        <form action="update_fabric_program.php" method="POST">
                            <!-- Include fabric program ID for identifying the record to update -->
                            <input type="hidden" name="fabric_program_id" value="<?= $orderRow['id'] ?>">

                            <!-- Add input fields for editing data -->
                            <div class="form-group">
                                <label for="edit_buyer">Buyer:</label>
                                <input type="text" class="form-control" id="edit_buyer" name='edit_buyer'
                                    value="<?= $orderRow['buyer'] ?>">
                            </div>

                            <div class="form-group">
                                <label for="edit_style">Style:</label>
                                <input type="text" class="form-control" id="edit_style" name='edit_style'
                                    value="<?= $orderRow['style'] ?>">
                            </div>

                            <div class="form-group">
                                <label for="edit_program_no">Program No:</label>
                                <input type="text" class="form-control" id="edit_program_no" name='edit_program_no'
                                    value="<?= $orderRow['program_no'] ?>">
                            </div>

                            <div class="form-group">
                                <label for="edit_required_qty">Req. Qty:</label>
                                <input type="number" class="form-control" id="edit_required_qty" name='edit_required_qty'
                                    value="<?= $orderRow['required_qty'] ?>">
                            </div>

                            <div class="form-group">
                                <label for="edit_unit">Unit:</label>
                                <select class="form-control" id="edit_unit" name="edit_unit">
                                    <option value="KG" <?= $orderRow['unit'] === 'KG' ? 'selected' : '' ?>>KG</option>
                                    <option value="GM" <?= $orderRow['unit'] === 'GM' ? 'selected' : '' ?>>GM</option>
                                    <option value="M.Ton" <?= $orderRow['unit'] === 'M.Ton' ? 'selected' : '' ?>>M.Ton</option>
                                    <!-- Add more currency options as needed -->
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="edit_program_date">Program Date:</label>
                                <input type="date" class="form-control" id="edit_program_date" name='edit_program_date'
                                    value="<?= $orderRow['programDate'] ?>">
                            </div>

                    </div>
                    <div class="modal-footer">
                        <div class="form-group">
                            <button type="submit" class="btn btn-warning">Update</button>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

                        </div>

                    </div>
                    </form>

                </div>
            </div>
        </div>
        </div>

    <?php endwhile; ?>
<?php else: ?>

<?php endif;

?>

<?php
require_once 'footer.php';
?>