<?php
require_once '../db_config.php';

// Check if fabric_no and yarn_name are set
if (isset($_GET['fabric_no'])) {
    // Retrieve fabric_no and yarn_name from the URL
    $fabricNo = $_GET['fabric_no'];

    // Modify the SQL query to consider yarn_name if available
    $sql = "SELECT * FROM `yarn_info` WHERE `fabric_no` = '$fabricNo'";
    
// Fetch yarn information based on fabric_no and yarn_name
$yarnResult = mysqli_query($conn, $sql);

// Check for errors
if (!$yarnResult) {
    echo "Error: " . mysqli_error($conn);
} else {
    // Check if yarn information is available
    if (mysqli_num_rows($yarnResult) > 0) {
        $yarnData = mysqli_fetch_assoc($yarnResult);
        ?>
        <h5>Yarn Information</h5>
        <table class="table table-bordered">
            <tr>
                <th>Yarn Name</th>
                <td><?= $yarnData['yarn_name'] ?></td>
            </tr>
            <tr>
                <th>Yarn Type</th>
                <td><?= $yarnData['yarn_type'] ?></td>
            </tr>
            <tr>
                <th>Yarn Color</th>
                <td><?= $yarnData['yarn_color'] ?></td>
            </tr>
            <tr>
                <th>Yarn Quantity</th>
                <td><?= $yarnData['yarn_qty'] ?></td>
            </tr>
        </table>
        <?php
    } else {
        echo '<p>No yarn information available.</p>';
    }
}}
else {
    echo '<p>Invalid request. Please provide fabric_no.</p>';
}

?>
