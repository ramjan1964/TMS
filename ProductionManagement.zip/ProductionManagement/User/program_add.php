<?php
require_once 'header.php';

// Initialize variables for error messages
$success = $error = '';

// Check if the form is submitted
if (isset($_POST['save_order'])) {
    // ... (your existing code to retrieve form data)
    $buyer = $_POST['buyer'];
    $style = $_POST['style'];
    $programNo = $_POST['Program_no'];
    $requiredQty = $_POST['required_qty'];
    $unit = $_POST['unit'];

    $programDate = $_POST['programDate'];

    // Check for empty fields
    $required_fields = ['buyer', 'style', 'Program_no', 'required_qty', 'unit', 'programDate'];
    $empty_fields = [];
    foreach ($required_fields as $field) {
        if (empty($_POST[$field])) {
            $empty_fields[] = ucfirst(str_replace('_', ' ', $field));
        }
    }

    if (!empty($empty_fields)) {
        $error = "Please fill in the following fields: " . implode(', ', $empty_fields);
    } else {
        // Insert data into the database
        $result = mysqli_query($conn, "INSERT INTO fabric_program (buyer, style, Program_no,required_qty,unit,programDate)
            VALUES ('$buyer', '$style', '$programNo',  '$requiredQty','$unit', '$programDate')");

        if ($result) {



            $success = "Fabric Program Saved Successfully!";

        } else {
            $error = "Error while saving order: " . mysqli_error($conn);
        }

    }
}

?>

<!-- Rest of your HTML code -->

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="javascript:avoi(0)">Add Fabric Program</a>
                </li>
            </ul>
        </div>
    </div>
    <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

    <div class="row animated fadeInUp">
        <!--SETTINGS-->

        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>
            <h4 class="section-subtitle"><b>Fabric Program</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data">
                                <h4 class="mb-lg">Add Fabric Program</h4>

                                <div class="form-group">
                                    <label for="buyer" class="col-sm-4 control-label">Buyer:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="buyer" name='buyer'
                                            placeholder="Type the buyer Name"
                                            value="<?= isset($buyer) ? $buyer : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="style" class="col-sm-4 control-label">Style:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="style" name='style'
                                            placeholder="Type the style No" value="<?= isset($style) ? $style : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="Program_no" class="col-sm-4 control-label">Program No:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="Program_no" name='Program_no'
                                            placeholder="Type the Program No"
                                            value="<?= isset($programNo) ? $programNo : '' ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <label for="required_qty" class="col-sm-4 control-label">Req. Qty:</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" id="required_qty" name='required_qty'
                                            placeholder="Type the required Fabric Qty"
                                            value="<?= isset($requiredQty) ? $requiredQty : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="unit" class="col-sm-4 control-label">Unit:</label>
                                    <div class="col-sm-8">
                                        <select class="form-control" id="unit" name="unit">
                                            <option value="KG" <?= isset($unit) && $unit === 'KG' ? 'selected' : '' ?>>KG
                                            </option>
                                            <option value="GM" <?= isset($unit) && $unit === 'GM' ? 'selected' : '' ?>>GM
                                            </option>
                                            <option value="M.Ton" <?= isset($unit) && $unit === 'M.Ton' ? 'selected' : '' ?>>M.Ton</option>
                                            <!-- Add more unit options as needed -->
                                        </select>
                                    </div>
                                </div>



                                <div class="form-group">
                                    <label for="programDate" class="col-sm-4 control-label">Program Date:</label>
                                    <div class="col-sm-8">
                                        <input type="date" class="form-control" id="programDate" name='programDate'
                                            value="<?= isset($programDate) ? $programDate : '' ?>">
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary" name="save_order"><i
                                                class="fa fa-save"></i>
                                            Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= -->

        <!--scroll to top-->
        <a href="#" class="scroll-to-top"><i class="fa fa-angle-double-up"></i></a>
    </div>
</div>

<?php
require_once 'footer.php';
?>