<?php
require_once '../db_config.php';
$fabricNo = isset($_GET['fabric_no']) ? $_GET['fabric_no'] : '';


require_once 'header.php';

// Initialize variables
$success = $error = '';
$yarnName = $yarnType = $yarnColor = $yarnQty = '';

// Check if form is submitted for adding yarn data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $yarnName = $_POST['yarn_name'];
    $yarnType = $_POST['yarn_type'];
    $yarnColor = $_POST['yarn_color'];
    $yarnQty = $_POST['yarn_qty'];

    // Insert yarn data into the database
    $insertSql = "INSERT INTO yarn_info (fabric_no, yarn_name, yarn_type, yarn_color, yarn_qty)
                  VALUES ('$fabricNo', '$yarnName', '$yarnType', '$yarnColor', '$yarnQty')";

    if ($conn->query($insertSql) === TRUE) {
        // Successfully inserted
        $success = 'Yarn data added successfully.';
    } else {
        // Error in insertion
        $error = 'Error adding yarn data: ' . $conn->error;
    }
}

// Fetch yarn data from the database
$yarnSql = "SELECT * FROM yarn_info where fabric_no='$fabricNo'";
$yarnResult = $conn->query($yarnSql);

?>

<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="manage_program.php">Manage Program</a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="fabric_data.php">Fabric Data</a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="javascript:avoi(0)">Yarn Info</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <!-- SETTINGS -->
        <div class="col-sm-6 col-sm-offset-3">
            <!-- Display success or error message -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success" role="alert">
                    <?= $success ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger" role="alert">
                    <?= $error ?>
                </div>
            <?php endif; ?>

            <h4 class="section-subtitle"><b>Yarn Data</b></h4>
            <div class="panel">
                <div class="panel-content">
                    <div class="row">
                        <div class="col-md-12">
                            <form class="form-horizontal" action="" method="POST">
                                <h4 class="mb-lg">Add Yarn Data</h4>

                                <div class="form-group">
                                    <label for="fabric_no" class="col-sm-4 control-label">Fabric No:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="fabric_no" name='fabric_no'
                                            placeholder="Type the Fabric No" value="<?= isset($fabricNo) ? $fabricNo : '' ?>" disabled>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="yarn_name" class="col-sm-4 control-label">Yarn Name:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="yarn_name" name='yarn_name'
                                               placeholder="Type the Yarn Name"
                                               value="<?= isset($yarnName) ? $yarnName : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="yarn_type" class="col-sm-4 control-label">Yarn Type:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="yarn_type" name='yarn_type'
                                               placeholder="Type the Yarn Type"
                                               value="<?= isset($yarnType) ? $yarnType : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="yarn_color" class="col-sm-4 control-label">Yarn Color:</label>
                                    <div class="col-sm-8">
                                        <input type="text" class="form-control" id="yarn_color" name='yarn_color'
                                               placeholder="Type the Yarn Color"
                                               value="<?= isset($yarnColor) ? $yarnColor : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="yarn_qty" class="col-sm-4 control-label">Yarn Qty:</label>
                                    <div class="col-sm-8">
                                        <input type="number" class="form-control" id="yarn_qty" name='yarn_qty'
                                               placeholder="Type the Yarn Qty"
                                               value="<?= isset($yarnQty) ? $yarnQty : '' ?>">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-4 col-sm-8">
                                        <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i>
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CONTENT -->
<!-- ========================================================= -->
<div class="content">
    <!-- content HEADER -->
    <!-- ========================================================= -->
    <div class="content-header">
        <!-- leftside content header -->
        <div class="leftside-content-header">
            <ul class="breadcrumbs">
                <li><i class="fa fa-home" aria-hidden="true"></i><a href="index.php">Dashboard</a></li>
                <li><i class="fa fa-tasks" aria-hidden="true"></i><a href="manage_program.php">Manage Program</a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="fabric_data.php">Fabric Data</a></li>
                <li><i class="fa fa-tag" aria-hidden="true"></i><a href="javascript:avoi(0)">Yarn Info</a></li>
            </ul>
        </div>
    </div>

    <div class="row animated fadeInUp">
        <div class="col-sm-12">
            <div class="panel">
                <div class="panel-content">
                    <h5>Fabric Data</h5>
                    <div class="table-responsive">
                        <table id="basic-table" class="data-table table table-striped nowrap table-hover table-bordered"
                               cellspacing="0" width="100%">
                            <thead>
                            <tr>
                            <th>Fabric No</th>
                                <th>Yarn Name</th>
                                <th>Yarn Type</th>
                                <th>Yarn Color</th>
                                <th>Yarn Qty</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php
                            if ($yarnResult->num_rows > 0) {
                                while ($row = $yarnResult->fetch_assoc()) {
                                    ?>
                                    <tr>
                                    <td><?= $row['fabric_no'] ?></td>
                                        <td><?= $row['yarn_name'] ?></td>
                                        <td><?= $row['yarn_type'] ?></td>
                                        <td><?= $row['yarn_color'] ?></td>
                                        <td><?= $row['yarn_qty'] ?></td>
                                        <td>
                                            <a href="#" class="btn btn-primary" data-toggle="modal"
                                               data-target="#yarn_data-view-modal-<?= $row['id'] ?>">View</a>
                                               <a href="#" class="btn btn-warning" data-toggle="modal"
                                               data-target="#yarn_data-edit-modal-<?= $row['id'] ?>">Edit</a>
                                            <a href='delete_yarn.php?yarnDelete=<?= base64_encode($row['id']) ?>'
                                               class='btn btn-danger'
                                               onclick="return confirm('Are you sure to delete this fabric Program?')"><i
                                                        class='fa fa-trash-o'></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr>
                                    <td colspan="5">No yarn data available</td>
                                </tr>
                                <?php
                            }
                            ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


    </div>


    <!-- Yarn Data View Modal -->
    <?php
    $fabricNo = isset($_GET['fabric_no']) ? $_GET['fabric_no'] : '';
    // Fetch yarn data from the database
    $yarnSql = "SELECT * FROM yarn_info where fabric_no='$fabricNo'";
    $yarnResult = $conn->query($yarnSql);

    if ($yarnResult->num_rows > 0) {
        while ($row = $yarnResult->fetch_assoc()) {
            ?>
            <div class="modal fade" id="yarn_data-view-modal-<?= $row['id'] ?>" tabindex="-1" role="dialog"
                 aria-labelledby="yarnDataViewModal" aria-hidden="true">
                <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header state modal-info">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                        aria-hidden="true">&times;</span></button>
                            <h4 class="modal-title" id="modal-info-label"><i class="fa fa-info"></i>Yarn Information:
                            </h4>
                        </div>
                        <div class="modal-body">
                            <table class="table table-bordered">
                                <!-- Your table headers here -->
                                <tr>
                                    <th>Yarn Name</th>
                                    <th>Yarn Type</th>
                                    <th>Yarn Color</th>
                                    <th>Yarn Qty</th>
                                </tr>
                                <tr>
                                    <td><?= $row['yarn_name'] ?></td>
                                    <td><?= $row['yarn_type'] ?></td>
                                    <td><?= $row['yarn_color'] ?></td>
                                    <td><?= $row['yarn_qty'] ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-warning" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
    ?>


<!-- Yarn Data Edit Modal -->
<?php
// Fetch yarn data from the database
$editYarnSql = "SELECT * FROM yarn_info where fabric_no='$fabricNo'";
$editYarnResult = $conn->query($editYarnSql);

if ($editYarnResult->num_rows > 0) {
    while ($row = $editYarnResult->fetch_assoc()) {
        ?>
        <div class="modal fade" id="yarn_data-edit-modal-<?= $row['id'] ?>" tabindex="-1" role="dialog"
             aria-labelledby="yarnDataEditModal" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header state modal-warning">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                    aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="modal-warning-label"><i class="fa fa-pencil"></i>Edit Yarn Data:
                        </h4>
                    </div>
                    <div class="modal-body">
                        <form class="form-horizontal" action="update_yarn.php" method="POST">
                            <input type="hidden" name="yarn_id" value="<?= $row['id'] ?>">

                            <div class="form-group">
                                <label for="edit_yarn_name" class="col-sm-4 control-label">Yarn Name:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="edit_yarn_name" name='edit_yarn_name'
                                           placeholder="Type the Yarn Name"
                                           value="<?= $row['yarn_name'] ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="edit_yarn_type" class="col-sm-4 control-label">Yarn Type:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="edit_yarn_type" name='edit_yarn_type'
                                           placeholder="Type the Yarn Type"
                                           value="<?= $row['yarn_type'] ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="edit_yarn_color" class="col-sm-4 control-label">Yarn Color:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control" id="edit_yarn_color" name='edit_yarn_color'
                                           placeholder="Type the Yarn Color"
                                           value="<?= $row['yarn_color'] ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="edit_yarn_qty" class="col-sm-4 control-label">Yarn Qty:</label>
                                <div class="col-sm-8">
                                    <input type="number" class="form-control" id="edit_yarn_qty" name='edit_yarn_qty'
                                           placeholder="Type the Yarn Qty"
                                           value="<?= $row['yarn_qty'] ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-sm-offset-4 col-sm-8">
                                    <button type="submit" class="btn btn-warning"><i class="fa fa-pencil"></i>
                                        Update
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
}
?>
</div>
</div>

<?php require_once 'footer.php'; ?>
